# Block2Box

Plugin Paper **1.20+ / 1.21+** de caisses (Vote / Legendaire / Epique / Mythique / Halloween) avec :
- un module **votifier interne** (remplace NuVotifier, compatible V1 et V2/NuVotifier — Top-Serveurs, Serveur-Prive, etc.)
- une commande **/invest** avec GUI et recompenses par palier de temps de jeu
- une configuration **100% YAML**, aucune base de donnees, tout dans `/plugins/Block2Box/`

---

## 1. Compilation

Le projet est un Maven standard.

```bash
mvn clean package
```

Le jar final est genere dans `target/Block2Box.jar`.

> Necessite un acces internet a `repo.papermc.io` (Paper API) et `repo.extendedclip.com` (PlaceholderAPI, en `provided`, optionnel a l'execution). Aucun de ces jars n'est redistribue dans ce depot : Maven les telechargera automatiquement au premier build.

Compile contre l'API `1.20.4-R0.1-SNAPSHOT` afin de garantir la compatibilite ascendante avec les serveurs Paper 1.20.x **et** 1.21.x (l'API Paper reste retro-compatible pour les plugins compiles contre une version anterieure).

### CI/CD GitHub Actions

Un workflow est fourni dans `.github/workflows/build.yml` :
- se declenche a chaque `push`/`pull request` sur `main`, ou manuellement depuis l'onglet **Actions** de GitHub ;
- compile le plugin avec Maven (JDK 21) et publie `Block2Box.jar` comme **artifact** telechargeable du run ;
- si vous poussez un tag de version (ex: `git tag v1.0.0 && git push origin v1.0.0`), une **Release GitHub** est creee automatiquement avec le jar attache.

Aucune configuration supplementaire n'est necessaire : il suffit de pousser ce depot sur GitHub.

---

## 2. Installation

1. Placez `Block2Box.jar` dans `/plugins/`.
2. Demarrez le serveur une premiere fois : l'arborescence suivante est generee automatiquement.
3. (Optionnel) Installez **PlaceholderAPI** si vous voulez que `/invest` utilise `%statistic_play_one_minute%` au lieu du compteur interne.

```
/plugins/Block2Box/
├── config.yml
├── crates/
│   ├── vote.yml
│   ├── legendaire.yml
│   ├── mythique.yml
│   └── locations.yml       (auto-genere : emplacements des caisses posees avec /block2box setcrate)
├── keys/
│   ├── vote.yml
│   ├── legendaire.yml
│   └── mythique.yml
├── votifier/
│   ├── public.key           (auto-genere au 1er demarrage)
│   ├── private.key          (auto-genere au 1er demarrage)
│   ├── antispam.yml         (auto-genere : cooldowns anti-spam par pseudo/IP)
│   └── votes.log            (auto-genere : historique des votes)
└── playerdata/
    └── <uuid>.yml           (auto-genere par joueur : playtime interne + paliers /invest deja recus)
```

> **Note sur la structure** : en plus des dossiers demandes (`/crates/`, `/keys/`, `/config.yml`, `/votifier/`), le plugin cree `crates/locations.yml` (pour retenir quelle caisse est posee a quel endroit), `votifier/antispam.yml` (persistance de l'anti-spam entre redemarrages) et `playerdata/` (compteur de playtime interne + paliers deja recus). Tout reste 100% YAML, sans base de donnees.

---

## 3. Utilisation en jeu

### Poser une caisse
```
/block2box setcrate <vote|legendaire|epique|mythique|halloween>
```
Regardez le bloc a transformer, puis executez la commande. Le bloc est remplace par le `block:` defini dans le YML de la caisse, et l'hologramme (si active) apparait au-dessus.

### Ouvrir une caisse
- **Clic droit** sur le bloc de caisse : ouvre un **apercu** (preview-gui) listant **toutes** les recompenses possibles configurees et leur pourcentage de chance (la preview s'agrandit automatiquement jusqu'a 54 slots si besoin, rien n'est jamais coupe). Aucune cle n'est consommee.
- **Sneak (accroupi) + clic droit** : ouvre reellement la caisse (consomme une cle virtuelle ou l'item physique en main selon `key-type`), tire une recompense au hasard selon les `chance` configurees, et la donne au joueur. C'est indique directement dans l'hologramme de chaque caisse.

### Cles
- `key-type: PHYSICAL` (par defaut sur les 4 caisses) : le joueur doit tenir en main l'item cle (un Tripwire Hook enchante, apparence definie dans `item:` du fichier `/keys/<caisse>.yml`), genere par `/block2box givekey` ou obtenu en recompense. Si le joueur est hors-ligne au moment ou la cle est donnee (ex: vote recu pendant qu'il est deconnecte), elle est mise en attente et ajoutee automatiquement a son inventaire a sa prochaine connexion.
- `key-type: VIRTUAL` (optionnel) : le solde est stocke par joueur dans `/keys/<caisse>.yml` au lieu d'un item. Verifiable avec `/block2box keys`.

### Commandes
| Commande | Permission | Description |
|---|---|---|
| `/block2box givekey <joueur> <caisse> <montant>` | `block2box.givekey` | Donne des cles (physiques ou virtuelles selon la caisse). Fonctionne aussi hors-ligne : la cle physique est mise en attente et livree a la reconnexion. |
| `/block2box setcrate <caisse>` | `block2box.setcrate` | Transforme le bloc regarde en caisse. |
| `/block2box removecrate` | `block2box.setcrate` | Retire la caisse (et son hologramme) du bloc regarde, sans toucher au bloc lui-meme. |
| `/block2box reload` | `block2box.reload` | Recharge `config.yml` + tous les `crates/*.yml`. |
| `/block2box keys` | `block2box.use` | Affiche vos soldes de cles virtuelles (s'il en reste en VIRTUAL). |
| `/block2box votifier` | `block2box.votifier` | Affiche la cle publique RSA (V1) et le token (V2) a coller sur le site de vote. |
| `/invest` | `block2box.use` | Ouvre le GUI de temps de jeu / recompenses. |
| `/vote` | *(aucune, public)* | Affiche les liens des sites de vote configures dans `config.yml` (`vote-links`). |
| `/halloween` | `block2box.use` | Ouvre le GUI des 8 quetes Halloween du joueur et leur progression (voir `halloween-quests.yml`). |

---

## 4. Le module Vote (votifier interne)

Dans `config.yml` :
```yaml
votifier:
  enabled: true
  host: "0.0.0.0"
  port: 8192
  token: "CHANGE_ME_AUTO_GENERATED"   # auto-genere au premier demarrage si non modifie
  reward-command: "block2box givekey %player% vote 1"
```

- Au premier demarrage, une paire de cles **RSA 2048** est generee dans `/votifier/public.key` et `private.key` (format DER brut, standard historique Votifier).
- Le serveur TCP interne accepte **les deux protocoles** :
  - **V1** (bloc RSA 256 octets chiffre avec la cle publique) — utilisez `/block2box votifier` pour recuperer la cle publique a coller sur le site.
  - **V2 / NuVotifier** (JSON signe en HMAC-SHA256 avec un token) — utilisez `/block2box votifier` pour recuperer le token a coller sur le site.
- **Anti-spam** : 1 vote recompense toutes les `cooldown-hours` heures (3h par defaut), verifie par pseudo et/ou IP selon `check-by`. Persiste dans `votifier/antispam.yml`.
- Chaque vote (accepte ou bloque) est journalise dans `votifier/votes.log`.
- **Confirmation systematique en console** : des qu'un vote valide arrive (signature/dechiffrement OK), le plugin log toujours `[Block2Box] ✓ Vote valide recu de '<site>' (protocole V1/V2) pour le joueur <pseudo>` — meme sans `votifier.debug: true`. Pratique pour verifier en direct que chaque site de vote est bien connecte au plugin des que vous cliquez sur "tester" dans son panel.
- Quand un vote est accepte, la commande `reward-command` est executee en console (par defaut : donne 1 cle Vote).

---

## 5. Le module /invest (playtime)

- Utilise `%statistic_play_one_minute%` via **PlaceholderAPI** si le plugin est present et `invest.use-placeholderapi: true`, sinon un **compteur interne** (incremente chaque seconde pour les joueurs connectes, en excluant l'AFK si `count-afk: false`, seuil `afk-threshold-seconds`).
- Les paliers sont definis dans `config.yml` sous `invest.playtime-rewards` (cle = nombre d'heures). Des qu'un joueur atteint un palier, la recompense est **distribuee automatiquement** (pas besoin de cliquer) et marquee comme obtenue dans `playerdata/<uuid>.yml` pour eviter les doublons.
- Le GUI `/invest` affiche votre temps de jeu total et l'etat de chaque palier (obtenu / verrouille, avec temps restant estime).

---

## 6. Systeme de recompenses des caisses

Chaque `crates/<id>.yml` contient une liste `rewards:` :

```yaml
rewards:
  - id: "exemple"
    chance: 10.0              # poids relatif (les chances sont normalisees sur le total de la liste)
    rarity: "RARE"             # texte libre, affiche dans l'apercu
    display-item:
      material: DIAMOND_SWORD
      name: "&5&lMon Item"
      amount: 1
      lore: ["&7Ligne 1", "&7Ligne 2"]
      glow: true                # glint visuel meme sans enchantement reel
    enchantments:
      - "SHARPNESS:6"           # niveaux au-dela du max vanilla acceptes
      - "UNBREAKING:3"
    commands:
      - "minecraft:give %player% diamond 5" # execute en console, %player% remplace
    give-key: "legendaire:1"    # optionnel : "<caisse>:<montant>" — donne une autre cle en bonus
    broadcast: true
    broadcast-message: "&e%player% a gagne gros !"
```

Les couleurs supportent `&` (legacy) et `&#RRGGBB` (hexadecimal).

### Garde-fou Caisse Mythique
`mythique.yml` a `obtainable: false`. Le plugin **bloque automatiquement** toute entree `give-key: "mythique:..."` placee par erreur dans `vote.yml` ou `legendaire.yml` (avec un avertissement en console) : la seule facon d'obtenir une cle Mythique reste :
```
/block2box givekey <joueur> mythique <montant>
```
(reservee aux recompenses exceptionnelles decidees par l'equipe).

---

## 7. Recompenses fournies par defaut (equilibrage)

- **Vote** (41 recompenses) : plafond argent 10 000 $.
- **Legendaire** (43 recompenses) : plafond argent 20 000 $.
- **Epique** (42 recompenses) : plafond argent 10 000 $.
- **Mythique** (41 recompenses, non-obtenable automatiquement) : plafond argent 20 000 $.
- **Halloween** (44 recompenses, saisonniere) : plafond argent 15 000 $.

Chaque caisse suit desormais une vraie courbe de rarete (rarity: `POUBELLE` -> `COMMUN` -> `PEU COMMUN` -> `RARE` -> `EPIQUE` -> `LEGENDAIRE`/`MYTHIQUE`), du bloc de terre inutile jusqu'au jackpot en argent, cle bonus ou equipement plein enchant. C'est volontaire : si toutes les recompenses etaient excellentes, le pourcentage de chance n'aurait plus aucun sens. Vous pouvez ajuster librement `chance:` sur chaque entree puis `/block2box reload`.

### Recompenses en argent
Les caisses peuvent donner de l'argent via la commande `b2c give %player% <montant>` (executee en console, comme n'importe quelle autre commande dans `commands:`). Plafonds respectes dans les fichiers fournis :
- Vote / Epique : 10 000 $ max
- Legendaire / Mythique : 20 000 $ max
- Halloween : 15 000 $ max

Si votre plugin economique utilise une autre commande (Vault, EssentialsX...), remplacez `b2c give %player% <montant>` par la syntaxe correspondante dans les fichiers `crates/*.yml`, puis `/block2box reload`.

### Quetes Halloween (`/halloween`)
8 quetes fixes par joueur (kills, minage, pose de blocs), definies dans `halloween-quests.yml`. Chaque quete ne se valide qu'une fois et donne 2 a 5 cles Halloween a la completion :

| Quete | Objectif | Cles |
|---|---|---|
| Tueur de Zombies | Tuer 40 Zombies | 2 |
| Chasseur d'Araignees | Tuer 25 Araignees | 2 |
| Recolte de Citrouilles | Miner 80 Citrouilles | 2 |
| Sculpteur de Jack O'Lantern | Poser 15 Jack O'Lantern | 2 |
| Exterminateur de Squelettes | Tuer 30 Squelettes | 3 |
| Chasseur de Sorcieres | Tuer 8 Sorcieres | 3 |
| Collecteur d'Ames | Miner 40 Soul Sand | 3 |
| Le Cauchemar Ultime | Tuer 3 Squelettes du Wither | 5 |

Desactivable hors-saison via `season.enabled: false` dans `halloween-quests.yml` (le `/halloween` affiche alors un message "saison terminee" au lieu du GUI). La progression de chaque joueur est sauvegardee dans `/halloween/<uuid>.yml`.

Aucune recompense par defaut ne distribue de monnaie/coins : tout est en objets ou en cles bonus. Vous pouvez librement editer ces fichiers YML puis faire `/block2box reload`.

---

## 8. Limitations connues / notes d'implementation

- Le champ `commands:` d'une recompense peut executer n'importe quelle commande console (`%player%` remplace) : items vanilla, permissions, votre plugin d'economie si vous en ajoutez un, etc. Aucune commande economique n'est utilisee par defaut.
- `/block2box givekey` fonctionne desormais hors-ligne pour toutes les caisses, y compris `PHYSICAL` : la cle est mise en attente (`data.pending` dans `/keys/<caisse>.yml`) et ajoutee automatiquement a l'inventaire du joueur a sa prochaine connexion.
- Les hologrammes utilisent des entites `TEXT_DISPLAY` (Minecraft 1.19.4+), affichees au-dessus du bloc ; leur contenu est statique par caisse (pas de placeholder par-joueur, une entite hologramme etant partagee par tous les joueurs qui la voient).
- Le protocole votifier V2 implemente ici est une reimplementation maison (RSA 2048 + HMAC-SHA256) suivant les specifications publiques NuVotifier ; testez avec votre site de vote avant mise en production.
