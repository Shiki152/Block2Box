package fr.block2box.votifier;

import fr.block2box.config.ConfigManager;
import fr.block2box.util.FileUtil;
import fr.block2box.util.HexColor;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class VoteHandler {

    private final Plugin plugin;
    private final ConfigManager configManager;
    private final AntiSpamManager antiSpamManager;
    private final VoteLogger voteLogger;

    // Retient les sites de vote deja "vus" au moins une fois, pour distinguer le
    // message "site lie" (premiere fois) du message "vote recu" (a chaque fois).
    private final File linkedSitesFile;
    private YamlConfiguration linkedSitesConfig;

    public VoteHandler(Plugin plugin, ConfigManager configManager, AntiSpamManager antiSpamManager, VoteLogger voteLogger) {
        this.plugin = plugin;
        this.configManager = configManager;
        this.antiSpamManager = antiSpamManager;
        this.voteLogger = voteLogger;
        this.linkedSitesFile = new File(plugin.getDataFolder(), "votifier/linked-sites.yml");
    }

    public void load() {
        FileUtil.ensureDir(linkedSitesFile.getParentFile());
        if (!linkedSitesFile.exists()) {
            try {
                linkedSitesFile.createNewFile();
            } catch (IOException e) {
                plugin.getLogger().severe("[Block2Box] Impossible de creer linked-sites.yml : " + e.getMessage());
            }
        }
        linkedSitesConfig = YamlConfiguration.loadConfiguration(linkedSitesFile);
    }

    /**
     * Retourne true si c'est la toute premiere fois qu'un vote valide arrive de ce
     * site (par nom de service), et enregistre le site comme "lie" pour la suite.
     */
    private synchronized boolean isFirstTimeLinking(String serviceName) {
        String key = serviceName.toLowerCase().replace(".", "_").replace(" ", "_");
        List<String> known = new ArrayList<>(linkedSitesConfig.getStringList("sites"));
        if (known.contains(key)) {
            return false;
        }
        known.add(key);
        linkedSitesConfig.set("sites", known);
        try {
            linkedSitesConfig.save(linkedSitesFile);
        } catch (IOException e) {
            plugin.getLogger().severe("[Block2Box] Impossible de sauvegarder linked-sites.yml : " + e.getMessage());
        }
        return true;
    }

    /**
     * Appele depuis le thread reseau du votifier. Bascule sur le thread principal
     * pour toute interaction avec l'API Bukkit.
     */
    public void handleVote(String serviceName, String username, String address, String timestamp, String protocol) {
        boolean allowed = antiSpamManager.checkAndRecord(username, address);
        voteLogger.log(serviceName, username, address, allowed, allowed ? null : "anti-spam cooldown");

        if (!allowed) {
            if (configManager.get().getBoolean("votifier.debug", false)) {
                plugin.getLogger().info("[Block2Box] Vote recu : service=" + serviceName + " joueur=" + username
                        + " ip=" + address + " -> BLOQUE (anti-spam)");
            }
            return;
        }

        boolean firstLink = isFirstTimeLinking(serviceName);

        if (firstLink) {
            // Premiere fois qu'on entend parler de ce site : message distinct, plus visible,
            // qui confirme que la LIAISON avec ce site est etablie (config port + cle/token OK).
            String linkedMsg = configManager.get().getString("votifier.site-linked-message",
                    "&aLe site &e%site% &aa bien ete lie au plugin !");
            String finalLinkedMsg = configManager.prefix() + HexColor.translate(linkedMsg).replace("%site%", serviceName);

            plugin.getLogger().info("[Block2Box] " + org.bukkit.ChatColor.stripColor(finalLinkedMsg));
            Bukkit.getScheduler().runTask(plugin, () -> {
                for (Player p : Bukkit.getOnlinePlayers()) {
                    if (p.hasPermission("block2box.admin")) {
                        p.sendMessage(finalLinkedMsg);
                    }
                }
            });
        } else {
            // Deja lie precedemment : simple confirmation de vote recu, a chaque fois.
            plugin.getLogger().info("[Block2Box] \u2713 Vote valide recu de '" + serviceName + "' (protocole " + protocol
                    + ") pour le joueur " + username + " -> recompense distribuee.");
        }

        Bukkit.getScheduler().runTask(plugin, () -> {
            String rewardCommand = configManager.get().getString("votifier.reward-command",
                    "block2box givekey %player% vote 1").replace("%player%", username);
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), rewardCommand);

            Player player = Bukkit.getPlayerExact(username);
            if (player != null) {
                String rawMsg = configManager.get().getString("votifier.vote-message", "");
                if (rawMsg != null && !rawMsg.isBlank()) {
                    player.sendMessage(configManager.prefix() + HexColor.translate(rawMsg).replace("%player%", username));
                }
            }
        });
    }
}
