package fr.block2box.integration;

import fr.block2box.crates.CrateDefinition;
import fr.block2box.crates.CrateManager;
import fr.block2box.crates.KeyManager;
import fr.block2box.invest.PlaytimeManager;
import fr.block2box.util.HexColor;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.util.Map;
import java.util.TreeMap;

/**
 * Expose les placeholders Block2Box a PlaceholderAPI. N'est enregistree (voir
 * Block2Box#onEnable) que si PlaceholderAPI est detecte sur le serveur.
 *
 * Placeholders disponibles (prefixe %block2box_...%) :
 *  playtime_hours            -> heures de jeu, entier arrondi vers le bas
 *  playtime_exact            -> heures de jeu, decimal a 2 chiffres
 *  playtime_formatted        -> "12h 34m"
 *  next_milestone_hours      -> heures restantes avant le prochain palier /invest ("0" si tous atteints)
 *  next_milestone_name       -> nom du prochain palier ("Termine" si tous atteints)
 *  keys_<caisse>             -> nombre de cles (physiques en inventaire, ou solde si VIRTUAL)
 *  pending_keys_<caisse>     -> cles physiques en attente (donnees hors-ligne, pas encore livrees)
 *
 * Exemples : %block2box_playtime_formatted%, %block2box_keys_vote%, %block2box_keys_mythique%
 */
public class Block2BoxExpansion extends PlaceholderExpansion {

    private final Plugin plugin;
    private final PlaytimeManager playtimeManager;
    private final CrateManager crateManager;

    public Block2BoxExpansion(Plugin plugin, PlaytimeManager playtimeManager, CrateManager crateManager) {
        this.plugin = plugin;
        this.playtimeManager = playtimeManager;
        this.crateManager = crateManager;
    }

    @Override
    public String getIdentifier() {
        return "block2box";
    }

    @Override
    public String getAuthor() {
        return "Block2Box";
    }

    @Override
    public String getVersion() {
        return plugin.getDescription().getVersion();
    }

    @Override
    public boolean persist() {
        // Reste enregistre meme apres un /papi reload (pas besoin que Block2Box redemarre).
        return true;
    }

    @Override
    public String onPlaceholderRequest(Player player, String params) {
        if (player == null) return "";
        String p = params.toLowerCase();

        switch (p) {
            case "playtime_hours":
                return String.valueOf((int) playtimeManager.getPlaytimeHours(player));
            case "playtime_exact":
                return String.format("%.2f", playtimeManager.getPlaytimeHours(player));
            case "playtime_formatted":
                return formatDuration(playtimeManager.getPlaytimeHours(player));
            case "next_milestone_hours":
                return String.valueOf(nextMilestoneHoursRemaining(player));
            case "next_milestone_name":
                return nextMilestoneName(player);
            default:
                break;
        }

        if (p.startsWith("pending_keys_")) {
            String crateId = p.substring("pending_keys_".length());
            KeyManager keyManager = crateManager.getKeyManager();
            return String.valueOf(keyManager.getPendingPhysicalKeys(crateId, player.getUniqueId()));
        }

        if (p.startsWith("keys_")) {
            String crateId = p.substring("keys_".length());
            return String.valueOf(keyCount(player, crateId));
        }

        return null; // placeholder Block2Box inconnu : laisse PAPI afficher son propre "invalide"
    }

    private int keyCount(Player player, String crateId) {
        CrateDefinition def = crateManager.getCrate(crateId);
        if (def == null) return 0;
        KeyManager keyManager = crateManager.getKeyManager();
        if (def.getKeyType() == CrateDefinition.KeyType.VIRTUAL) {
            return keyManager.getVirtualKeys(def.getId(), player.getUniqueId());
        }
        return keyManager.countPhysicalKeys(player, def.getId());
    }

    private String formatDuration(double hours) {
        long totalMinutes = Math.round(hours * 60);
        long h = totalMinutes / 60;
        long m = totalMinutes % 60;
        return h + "h " + m + "m";
    }

    private int nextMilestoneHoursRemaining(Player player) {
        double hours = playtimeManager.getPlaytimeHours(player);
        for (Map.Entry<Integer, ConfigurationSection> entry : playtimeManager.getMilestones().entrySet()) {
            if (entry.getKey() > hours) {
                return (int) Math.ceil(entry.getKey() - hours);
            }
        }
        return 0;
    }

    private String nextMilestoneName(Player player) {
        double hours = playtimeManager.getPlaytimeHours(player);
        TreeMap<Integer, ConfigurationSection> milestones = playtimeManager.getMilestones();
        for (Map.Entry<Integer, ConfigurationSection> entry : milestones.entrySet()) {
            if (entry.getKey() > hours) {
                return HexColor.translate(entry.getValue().getString("display-name", entry.getKey() + "h"));
            }
        }
        return "Termine";
    }
}
