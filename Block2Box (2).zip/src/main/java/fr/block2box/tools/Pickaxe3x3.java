package fr.block2box.tools;

import fr.block2box.util.HexColor;
import org.bukkit.ChatColor;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

import java.util.ArrayList;
import java.util.List;

/**
 * Pioches 3x3 : outils qui minent le bloc vise + les 8 blocs autour (voir
 * Pickaxe3x3Listener). L'API Paper 1.20.4 ne permet pas de modifier la
 * durabilite maximum native d'un outil (setMaxDamage n'existe qu'a partir de
 * la 1.20.5), donc on gere une "duree de vie" 100% custom : l'item est
 * marque Unbreakable cote vanilla (jamais de casse via la barre de durete
 * normale) et un compteur d'utilisations restantes est stocke dans son
 * PersistentDataContainer + affiche dans le lore. Quand le compteur atteint
 * 0, l'outil est retire de la main du joueur (voir le listener).
 */
public final class Pickaxe3x3 {

    private static NamespacedKey keyFlag;
    private static NamespacedKey keyUses;
    private static NamespacedKey keyMax;

    private Pickaxe3x3() {
    }

    /**
     * A appeler une fois dans onEnable, avant tout chargement de caisse.
     */
    public static void init(Plugin plugin) {
        keyFlag = new NamespacedKey(plugin, "pickaxe3x3");
        keyUses = new NamespacedKey(plugin, "pickaxe3x3_uses");
        keyMax = new NamespacedKey(plugin, "pickaxe3x3_max");
    }

    /**
     * Marque un item (deja construit par ItemBuilder) comme pioche 3x3 avec
     * le nombre d'utilisations donne. Appele une seule fois, au chargement
     * du YML de la recompense.
     */
    public static void tag(ItemStack item, int maxUses) {
        if (item == null || maxUses <= 0) return;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return;

        meta.getPersistentDataContainer().set(keyFlag, PersistentDataType.BYTE, (byte) 1);
        meta.getPersistentDataContainer().set(keyUses, PersistentDataType.INTEGER, maxUses);
        meta.getPersistentDataContainer().set(keyMax, PersistentDataType.INTEGER, maxUses);

        // Unbreakable cote vanilla : c'est notre compteur custom qui gere entierement
        // la duree de vie, la barre de durabilite normale ne doit jamais intervenir.
        meta.setUnbreakable(true);
        meta.addItemFlags(ItemFlag.HIDE_UNBREAKABLE, ItemFlag.HIDE_ATTRIBUTES);

        List<String> lore = meta.hasLore() && meta.getLore() != null ? new ArrayList<>(meta.getLore()) : new ArrayList<>();
        lore.add("");
        lore.add(HexColor.translate("&6&lMine 3x3 blocs par coup !"));
        lore.add(buildUsesLoreLine(maxUses, maxUses));
        meta.setLore(lore);

        item.setItemMeta(meta);
    }

    public static boolean isPickaxe3x3(ItemStack item) {
        if (item == null) return false;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return false;
        Byte flag = meta.getPersistentDataContainer().get(keyFlag, PersistentDataType.BYTE);
        return flag != null && flag == (byte) 1;
    }

    /**
     * Consomme une utilisation sur l'item (met a jour PDC + lore en place).
     * Retourne le nombre d'utilisations restantes (0 si l'outil vient de
     * s'epuiser, -1 si l'item n'est pas une pioche 3x3 valide).
     */
    public static int consumeOne(ItemStack item) {
        if (item == null) return -1;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return -1;

        Integer left = meta.getPersistentDataContainer().get(keyUses, PersistentDataType.INTEGER);
        Integer max = meta.getPersistentDataContainer().get(keyMax, PersistentDataType.INTEGER);
        if (left == null || max == null) return -1;

        left = Math.max(0, left - 1);
        meta.getPersistentDataContainer().set(keyUses, PersistentDataType.INTEGER, left);

        List<String> lore = meta.hasLore() && meta.getLore() != null ? new ArrayList<>(meta.getLore()) : new ArrayList<>();
        String newLine = buildUsesLoreLine(left, max);
        boolean replaced = false;
        for (int i = 0; i < lore.size(); i++) {
            if (ChatColor.stripColor(lore.get(i)).startsWith("Utilisations")) {
                lore.set(i, newLine);
                replaced = true;
                break;
            }
        }
        if (!replaced) lore.add(newLine);
        meta.setLore(lore);

        item.setItemMeta(meta);
        return left;
    }

    private static String buildUsesLoreLine(int left, int max) {
        return HexColor.translate("&7Utilisations : &f" + left + "&7/&f" + max);
    }
}
