package fr.block2box.tools;

import fr.block2box.crates.CrateManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.block.Container;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;

/**
 * Quand un joueur mine avec une pioche taguee Pickaxe3x3, casse aussi les 8
 * blocs autour du bloc vise, dans le plan perpendiculaire a son regard
 * (vise vers le haut/bas -> plan horizontal XZ, vise a l'horizontale ->
 * plan vertical adapte a l'axe regarde). Chaque bloc casse (y compris celui
 * vise) consomme une utilisation de la pioche.
 */
public class Pickaxe3x3Listener implements Listener {

    private final CrateManager crateManager;

    // Empeche la recursion infinie : quand on casse un bloc voisin via callEvent()
    // plus bas, ce meme listener serait sinon re-declenche (toujours un
    // BlockBreakEvent, toujours la pioche 3x3 en main) et recalculerait un
    // nouveau carre 3x3 autour de ce voisin, a l'infini (StackOverflowError).
    private boolean processing = false;

    public Pickaxe3x3Listener(CrateManager crateManager) {
        this.crateManager = crateManager;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        if (processing) return;

        Player player = event.getPlayer();
        ItemStack tool = player.getInventory().getItemInMainHand();
        if (!Pickaxe3x3.isPickaxe3x3(tool)) return;

        processing = true;
        try {
            mine3x3(event, player, tool);
        } finally {
            processing = false;
        }
    }

    private void mine3x3(BlockBreakEvent event, Player player, ItemStack tool) {
        Block center = event.getBlock();

        // Le bloc vise consomme lui aussi une utilisation (l'outil est Unbreakable
        // cote vanilla, notre compteur custom gere entierement sa duree de vie).
        int usesLeft = Pickaxe3x3.consumeOne(tool);
        player.getInventory().setItemInMainHand(tool);

        if (usesLeft > 0) {
            for (Block target : computeNeighbours(player, center)) {
                if (usesLeft <= 0) break;
                if (target.getType().isAir()) continue;
                if (target.getType().getHardness() < 0) continue; // incassable (bedrock, portails, etc.)
                if (target.getState() instanceof Container) continue; // jamais un coffre/four/shulker
                if (crateManager.getCrateIdAt(target.getLocation()) != null) continue; // jamais une caisse posee

                BlockBreakEvent extra = new BlockBreakEvent(target, player);
                Bukkit.getPluginManager().callEvent(extra);
                if (extra.isCancelled()) continue;

                target.breakNaturally(tool);

                usesLeft = Pickaxe3x3.consumeOne(tool);
                player.getInventory().setItemInMainHand(tool);
            }
        }

        if (usesLeft == 0) {
            player.getInventory().setItemInMainHand(null);
            player.getWorld().playSound(player.getLocation(), Sound.ENTITY_ITEM_BREAK, 1f, 1f);
            player.sendMessage(ChatColor.RED + "Votre pioche 3x3 s'est brisee apres usage intensif !");
        }
    }

    private List<Block> computeNeighbours(Player player, Block center) {
        Vector dir = player.getEyeLocation().getDirection();
        double absX = Math.abs(dir.getX());
        double absY = Math.abs(dir.getY());
        double absZ = Math.abs(dir.getZ());

        List<Block> result = new ArrayList<>(8);
        if (absY >= absX && absY >= absZ) {
            // Regard vertical (haut/bas) -> plan horizontal XZ
            for (int dx = -1; dx <= 1; dx++) {
                for (int dz = -1; dz <= 1; dz++) {
                    if (dx != 0 || dz != 0) result.add(center.getRelative(dx, 0, dz));
                }
            }
        } else if (absX >= absZ) {
            // Regard majoritairement sur l'axe X -> plan vertical YZ
            for (int dy = -1; dy <= 1; dy++) {
                for (int dz = -1; dz <= 1; dz++) {
                    if (dy != 0 || dz != 0) result.add(center.getRelative(0, dy, dz));
                }
            }
        } else {
            // Regard majoritairement sur l'axe Z -> plan vertical XY
            for (int dy = -1; dy <= 1; dy++) {
                for (int dx = -1; dx <= 1; dx++) {
                    if (dy != 0 || dx != 0) result.add(center.getRelative(dx, dy, 0));
                }
            }
        }
        return result;
    }
}
