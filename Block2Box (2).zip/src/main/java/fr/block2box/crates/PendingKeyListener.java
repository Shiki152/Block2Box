package fr.block2box.crates;

import fr.block2box.config.ConfigManager;
import fr.block2box.util.HexColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;

import java.util.Map;

/**
 * A la connexion d'un joueur, distribue les cles physiques mises en attente
 * pendant qu'il etait hors-ligne (ex: vote recu via le site alors qu'il
 * etait deconnecte, ou /block2box givekey execute sur un joueur absent).
 */
public class PendingKeyListener implements Listener {

    private final CrateManager crateManager;
    private final ConfigManager configManager;

    public PendingKeyListener(CrateManager crateManager, ConfigManager configManager) {
        this.crateManager = crateManager;
        this.configManager = configManager;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        KeyManager keyManager = crateManager.getKeyManager();

        for (Map.Entry<String, CrateDefinition> entry : crateManager.getAllCrates().entrySet()) {
            CrateDefinition def = entry.getValue();
            if (def.getKeyType() != CrateDefinition.KeyType.PHYSICAL) continue;

            int pending = keyManager.takePendingPhysicalKeys(def.getId(), player.getUniqueId());
            if (pending <= 0) continue;

            ItemStack keyItem = keyManager.buildPhysicalKeyItem(def.getId(), pending, player.getServer().getLogger());
            Map<Integer, ItemStack> overflow = player.getInventory().addItem(keyItem);
            for (ItemStack leftover : overflow.values()) {
                player.getWorld().dropItemNaturally(player.getLocation(), leftover);
            }

            player.sendMessage(configManager.prefix() + HexColor.translate(
                    "&aVous aviez &e" + pending + "x &acle(s) &e" + def.getDisplayName()
                            + " &aen attente, elles viennent d'etre ajoutees a votre inventaire !"));
        }
    }
}
