package fr.block2box.crates;

import fr.block2box.util.HexColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public final class PreviewGUI {

    private PreviewGUI() {
    }

    public static Inventory build(CrateDefinition def) {
        CratePreviewHolder holder = new CratePreviewHolder(def.getId());
        String title = HexColor.translate(def.getPreviewTitle());

        List<RewardDefinition> rewards = def.getRewards();
        double totalChance = def.totalChance();

        // La preview doit TOUJOURS montrer toutes les recompenses configurees : si la
        // taille definie dans le YML est trop petite, on l'agrandit automatiquement au
        // prochain multiple de 9 (jusqu'au maximum Bukkit de 54, soit 6 rangees).
        int neededSize = ((rewards.size() + 8) / 9) * 9;
        int size = Math.max(def.getPreviewSize(), Math.min(neededSize, 54));

        Inventory inv = Bukkit.createInventory(holder, size, title);
        holder.setInventory(inv);

        if (rewards.size() > 54) {
            Bukkit.getLogger().warning("[Block2Box] La caisse " + def.getId()
                    + " a " + rewards.size() + " recompenses, plus que les 54 slots max d'un inventaire : "
                    + (rewards.size() - 54) + " ne seront pas affichees dans la preview. Reduisez le nombre de recompenses.");
        }

        int slot = 0;
        for (RewardDefinition reward : rewards) {
            if (slot >= inv.getSize()) break;
            ItemStack display = reward.getDisplayItem();
            ItemMeta meta = display.getItemMeta();
            if (meta != null) {
                List<String> lore = meta.hasLore() && meta.getLore() != null ? new ArrayList<>(meta.getLore()) : new ArrayList<>();
                lore.add("");
                lore.add(HexColor.translate("&7Rarete: &f" + reward.getRarity()));
                double percent = totalChance > 0 ? (reward.getChance() / totalChance) * 100.0 : 0;
                lore.add(HexColor.translate(String.format("&7Chance: &f%.2f%%", percent)));
                meta.setLore(lore);
                display.setItemMeta(meta);
            }
            inv.setItem(slot, display);
            slot++;
        }

        // Remplit le reste avec des vitres de verre grises decoratives
        ItemStack filler = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta fillerMeta = filler.getItemMeta();
        if (fillerMeta != null) {
            fillerMeta.setDisplayName(" ");
            filler.setItemMeta(fillerMeta);
        }
        for (int i = slot; i < inv.getSize(); i++) {
            inv.setItem(i, filler);
        }

        return inv;
    }
}
