package fr.block2box.crates;

import fr.block2box.util.FileUtil;
import fr.block2box.util.ItemBuilder;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Logger;

/**
 * Gere le solde de cles virtuelles par joueur (stocke dans /keys/<crate>.yml
 * sous data.players) ainsi que la creation/verification des cles physiques.
 */
public class KeyManager {

    private final Plugin plugin;
    private final NamespacedKey physicalKeyMarker;
    private final Map<String, File> keyFiles = new HashMap<>();
    private final Map<String, YamlConfiguration> keyConfigs = new HashMap<>();

    public KeyManager(Plugin plugin) {
        this.plugin = plugin;
        this.physicalKeyMarker = new NamespacedKey(plugin, "block2box_key");
    }

    public void loadAll(String[] crateIds) {
        keyFiles.clear();
        keyConfigs.clear();
        File keysDir = new File(plugin.getDataFolder(), "keys");
        FileUtil.ensureDir(keysDir);

        for (String id : crateIds) {
            File file = new File(keysDir, id + ".yml");
            FileUtil.copyDefault(plugin, "keys/" + id + ".yml", file);
            YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
            keyFiles.put(id, file);
            keyConfigs.put(id, cfg);
        }
    }

    public void reloadAll() {
        for (Map.Entry<String, File> entry : keyFiles.entrySet()) {
            keyConfigs.put(entry.getKey(), YamlConfiguration.loadConfiguration(entry.getValue()));
        }
    }

    private void save(String crateId) {
        YamlConfiguration cfg = keyConfigs.get(crateId);
        File file = keyFiles.get(crateId);
        if (cfg == null || file == null) return;
        try {
            cfg.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("[Block2Box] Impossible de sauvegarder keys/" + crateId + ".yml : " + e.getMessage());
        }
    }

    // ---------------- Cles virtuelles ----------------

    public int getVirtualKeys(String crateId, UUID uuid) {
        YamlConfiguration cfg = keyConfigs.get(crateId);
        if (cfg == null) return 0;
        return cfg.getInt("data.players." + uuid, 0);
    }

    public void addVirtualKeys(String crateId, UUID uuid, int amount) {
        YamlConfiguration cfg = keyConfigs.get(crateId);
        if (cfg == null) return;
        int current = cfg.getInt("data.players." + uuid, 0);
        cfg.set("data.players." + uuid, current + amount);
        save(crateId);
    }

    /**
     * Retire des cles virtuelles, retourne true si le solde etait suffisant.
     */
    public boolean removeVirtualKeys(String crateId, UUID uuid, int amount) {
        YamlConfiguration cfg = keyConfigs.get(crateId);
        if (cfg == null) return false;
        int current = cfg.getInt("data.players." + uuid, 0);
        if (current < amount) return false;
        cfg.set("data.players." + uuid, current - amount);
        save(crateId);
        return true;
    }

    // ---------------- Cles physiques ----------------

    public NamespacedKey getPhysicalKeyMarker() {
        return physicalKeyMarker;
    }

    public ItemStack buildPhysicalKeyItem(String crateId, int amount, Logger logger) {
        YamlConfiguration cfg = keyConfigs.get(crateId);
        ConfigurationSection itemSection = cfg != null ? cfg.getConfigurationSection("item") : null;
        ItemStack item;
        if (itemSection != null) {
            item = ItemBuilder.fromSection(itemSection, java.util.List.of(), logger);
        } else {
            item = new ItemStack(org.bukkit.Material.TRIPWIRE_HOOK);
        }
        item.setAmount(Math.max(1, amount));

        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.getPersistentDataContainer().set(physicalKeyMarker, org.bukkit.persistence.PersistentDataType.STRING, crateId);
            item.setItemMeta(meta);
        }
        return item;
    }

    public boolean isPhysicalKeyFor(ItemStack item, String crateId) {
        if (item == null || item.getType().isAir()) return false;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return false;
        String tag = meta.getPersistentDataContainer().get(physicalKeyMarker, org.bukkit.persistence.PersistentDataType.STRING);
        return crateId.equalsIgnoreCase(tag);
    }

    /**
     * Compte le nombre total de cles physiques d'une caisse donnee dans tout
     * l'inventaire du joueur (tous les slots, pas seulement la main). Utilise
     * notamment par l'expansion PlaceholderAPI.
     */
    public int countPhysicalKeys(Player player, String crateId) {
        int total = 0;
        for (ItemStack item : player.getInventory().getContents()) {
            if (isPhysicalKeyFor(item, crateId)) {
                total += item.getAmount();
            }
        }
        return total;
    }

    /**
     * Retire une cle physique de la main du joueur. Retourne true si retiree avec succes.
     */
    public boolean consumePhysicalKey(Player player, String crateId) {
        PlayerInventory inv = player.getInventory();
        ItemStack hand = inv.getItemInMainHand();
        if (!isPhysicalKeyFor(hand, crateId)) return false;
        hand.setAmount(hand.getAmount() - 1);
        return true;
    }

    // ---------------- Cles physiques en attente (joueur hors-ligne) ----------------
    // Ex: vote recu via le site pendant que le joueur est deconnecte. La cle est mise
    // de cote et donnee automatiquement comme item a sa prochaine connexion (voir
    // PendingKeyListener).

    public int getPendingPhysicalKeys(String crateId, UUID uuid) {
        YamlConfiguration cfg = keyConfigs.get(crateId);
        if (cfg == null) return 0;
        return cfg.getInt("data.pending." + uuid, 0);
    }

    public void addPendingPhysicalKeys(String crateId, UUID uuid, int amount) {
        YamlConfiguration cfg = keyConfigs.get(crateId);
        if (cfg == null) return;
        int current = cfg.getInt("data.pending." + uuid, 0);
        cfg.set("data.pending." + uuid, current + amount);
        save(crateId);
    }

    /**
     * Recupere et remet a zero le nombre de cles physiques en attente pour ce joueur.
     */
    public int takePendingPhysicalKeys(String crateId, UUID uuid) {
        YamlConfiguration cfg = keyConfigs.get(crateId);
        if (cfg == null) return 0;
        int current = cfg.getInt("data.pending." + uuid, 0);
        if (current > 0) {
            cfg.set("data.pending." + uuid, null);
            save(crateId);
        }
        return current;
    }
}
