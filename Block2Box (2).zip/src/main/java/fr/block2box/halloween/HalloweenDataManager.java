package fr.block2box.halloween;

import fr.block2box.util.FileUtil;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Stocke, par joueur, dans /plugins/Block2Box/halloween/<uuid>.yml :
 *  - progress.<quete> : compteur actuel
 *  - completed : liste des quetes deja terminees (evite de redonner la recompense)
 */
public class HalloweenDataManager {

    private final Plugin plugin;
    private final File folder;
    private final Map<UUID, YamlConfiguration> cache = new HashMap<>();
    private final Map<UUID, File> files = new HashMap<>();

    public HalloweenDataManager(Plugin plugin) {
        this.plugin = plugin;
        this.folder = new File(plugin.getDataFolder(), "halloween");
        FileUtil.ensureDir(folder);
    }

    private YamlConfiguration configFor(UUID uuid) {
        return cache.computeIfAbsent(uuid, id -> {
            File file = new File(folder, id + ".yml");
            files.put(id, file);
            return YamlConfiguration.loadConfiguration(file);
        });
    }

    public void save(UUID uuid) {
        YamlConfiguration cfg = cache.get(uuid);
        File file = files.get(uuid);
        if (cfg == null || file == null) return;
        try {
            cfg.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("[Block2Box] Impossible de sauvegarder halloween/" + uuid + ".yml : " + e.getMessage());
        }
    }

    public int getProgress(UUID uuid, String questId) {
        return configFor(uuid).getInt("progress." + questId, 0);
    }

    public int addProgress(UUID uuid, String questId, int amount) {
        YamlConfiguration cfg = configFor(uuid);
        int current = cfg.getInt("progress." + questId, 0) + amount;
        cfg.set("progress." + questId, current);
        save(uuid);
        return current;
    }

    public boolean isCompleted(UUID uuid, String questId) {
        return configFor(uuid).getStringList("completed").contains(questId);
    }

    public void markCompleted(UUID uuid, String questId) {
        YamlConfiguration cfg = configFor(uuid);
        List<String> completed = new ArrayList<>(cfg.getStringList("completed"));
        if (!completed.contains(questId)) {
            completed.add(questId);
            cfg.set("completed", completed);
            save(uuid);
        }
    }

    public void unload(UUID uuid) {
        save(uuid);
        cache.remove(uuid);
        files.remove(uuid);
    }
}
