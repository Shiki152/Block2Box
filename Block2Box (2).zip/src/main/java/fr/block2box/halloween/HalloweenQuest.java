package fr.block2box.halloween;

import org.bukkit.Material;

/**
 * Represente une quete Halloween telle que definie dans halloween-quests.yml.
 */
public class HalloweenQuest {

    public enum Type {
        KILL_ENTITY, BREAK_BLOCK, PLACE_BLOCK
    }

    private final String id;
    private final String name;
    private final Type type;
    private final String target;
    private final int amount;
    private final int rewardKeys;
    private final Material icon;

    public HalloweenQuest(String id, String name, Type type, String target, int amount, int rewardKeys, Material icon) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.target = target;
        this.amount = amount;
        this.rewardKeys = rewardKeys;
        this.icon = icon;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Type getType() {
        return type;
    }

    public String getTarget() {
        return target;
    }

    public int getAmount() {
        return amount;
    }

    public int getRewardKeys() {
        return rewardKeys;
    }

    public Material getIcon() {
        return icon;
    }
}
