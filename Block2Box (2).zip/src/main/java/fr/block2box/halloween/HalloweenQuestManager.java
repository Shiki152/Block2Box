package fr.block2box.halloween;

import fr.block2box.config.ConfigManager;
import fr.block2box.crates.CrateManager;
import fr.block2box.util.FileUtil;
import fr.block2box.util.HexColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Charge halloween-quests.yml et gere la progression + la distribution des
 * cles Halloween a la completion de chaque quete (voir HalloweenListener
 * pour ce qui declenche addProgress).
 */
public class HalloweenQuestManager {

    private final Plugin plugin;
    private final ConfigManager configManager;
    private final CrateManager crateManager;
    private final HalloweenDataManager dataManager;
    private final List<HalloweenQuest> quests = new ArrayList<>();
    private boolean seasonEnabled = true;

    public HalloweenQuestManager(Plugin plugin, ConfigManager configManager, CrateManager crateManager) {
        this.plugin = plugin;
        this.configManager = configManager;
        this.crateManager = crateManager;
        this.dataManager = new HalloweenDataManager(plugin);
    }

    public void load() {
        File file = new File(plugin.getDataFolder(), "halloween-quests.yml");
        FileUtil.copyDefault(plugin, "halloween-quests.yml", file);
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);

        ConfigurationSection seasonSection = cfg.getConfigurationSection("season");
        seasonEnabled = seasonSection == null || seasonSection.getBoolean("enabled", true);

        quests.clear();
        List<?> list = cfg.getList("quests");
        if (list != null) {
            for (Object obj : list) {
                if (!(obj instanceof Map)) continue;
                @SuppressWarnings("unchecked")
                Map<String, Object> rawMap = (Map<String, Object>) obj;
                YamlConfiguration wrapper = new YamlConfiguration();
                ConfigurationSection section = wrapper.createSection("quest", rawMap);
                HalloweenQuest quest = parseQuest(section);
                if (quest != null) {
                    quests.add(quest);
                }
            }
        }
        plugin.getLogger().info("[Block2Box] " + quests.size() + " quetes Halloween chargees.");
    }

    private HalloweenQuest parseQuest(ConfigurationSection section) {
        String id = section.getString("id");
        if (id == null || id.isBlank()) return null;

        String name = HexColor.translate(section.getString("name", id));

        HalloweenQuest.Type type;
        try {
            type = HalloweenQuest.Type.valueOf(section.getString("type", "KILL_ENTITY").toUpperCase());
        } catch (IllegalArgumentException ex) {
            plugin.getLogger().warning("[Block2Box] Type de quete Halloween invalide pour '" + id + "', quete ignoree.");
            return null;
        }

        String target = section.getString("target", "").toUpperCase();
        int amount = Math.max(1, section.getInt("amount", 1));
        int rewardKeys = Math.max(1, section.getInt("reward-keys", 1));

        Material icon = Material.matchMaterial(section.getString("icon", "CHEST").toUpperCase());
        if (icon == null) icon = Material.CHEST;

        return new HalloweenQuest(id, name, type, target, amount, rewardKeys, icon);
    }

    public boolean isSeasonEnabled() {
        return seasonEnabled;
    }

    public List<HalloweenQuest> getQuests() {
        return quests;
    }

    public HalloweenDataManager getDataManager() {
        return dataManager;
    }

    /**
     * Appele par HalloweenListener a chaque kill/casse/pose pertinent.
     * Incremente toutes les quetes non-terminees qui correspondent, et
     * distribue la recompense des qu'une quete atteint son objectif.
     */
    public void addProgress(Player player, HalloweenQuest.Type type, String target, int amount) {
        if (!seasonEnabled || quests.isEmpty()) return;
        UUID uuid = player.getUniqueId();

        for (HalloweenQuest quest : quests) {
            if (quest.getType() != type) continue;
            if (!quest.getTarget().equalsIgnoreCase(target)) continue;
            if (dataManager.isCompleted(uuid, quest.getId())) continue;

            int progress = dataManager.addProgress(uuid, quest.getId(), amount);
            if (progress >= quest.getAmount()) {
                completeQuest(player, quest);
            }
        }
    }

    private void completeQuest(Player player, HalloweenQuest quest) {
        dataManager.markCompleted(player.getUniqueId(), quest.getId());
        crateManager.giveKeyToPlayer(player, "halloween", quest.getRewardKeys());

        player.sendMessage(configManager.prefix() + HexColor.translate(
                "&6&l🎃 Quete Halloween terminee : &e" + quest.getName()
                        + " &6&l! &7+" + quest.getRewardKeys() + " cle(s) &6Halloween&7."));
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.4f);
    }
}
