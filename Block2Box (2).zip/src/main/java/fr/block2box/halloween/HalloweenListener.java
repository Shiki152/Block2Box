package fr.block2box.halloween;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDeathEvent;

/**
 * Traduit les actions du jeu (kill, casse, pose) en progression de quete
 * Halloween via HalloweenQuestManager. Note : les blocs casses par une
 * pioche 3x3 (voir fr.block2box.tools) declenchent aussi de vrais
 * BlockBreakEvent pour chaque bloc annexe, donc ils comptent naturellement
 * ici aussi sans code specifique.
 */
public class HalloweenListener implements Listener {

    private final HalloweenQuestManager questManager;

    public HalloweenListener(HalloweenQuestManager questManager) {
        this.questManager = questManager;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onKill(EntityDeathEvent event) {
        Player killer = event.getEntity().getKiller();
        if (killer == null) return;
        questManager.addProgress(killer, HalloweenQuest.Type.KILL_ENTITY, event.getEntityType().name(), 1);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        questManager.addProgress(event.getPlayer(), HalloweenQuest.Type.BREAK_BLOCK, event.getBlock().getType().name(), 1);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent event) {
        questManager.addProgress(event.getPlayer(), HalloweenQuest.Type.PLACE_BLOCK, event.getBlockPlaced().getType().name(), 1);
    }
}
