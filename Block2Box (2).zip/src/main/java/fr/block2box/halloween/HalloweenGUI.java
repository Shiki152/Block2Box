package fr.block2box.halloween;

import fr.block2box.util.HexColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public final class HalloweenGUI {

    private HalloweenGUI() {
    }

    public static Inventory build(Player player, HalloweenQuestManager questManager) {
        HalloweenGUIHolder holder = new HalloweenGUIHolder();
        String title = HexColor.translate("&8🎃 &6&lQuetes Halloween &8🎃");
        Inventory inv = Bukkit.createInventory(holder, 27, title);
        holder.setInventory(inv);

        // Ligne du haut decorative
        ItemStack separator = new ItemStack(Material.ORANGE_STAINED_GLASS_PANE);
        ItemMeta sepMeta = separator.getItemMeta();
        if (sepMeta != null) {
            sepMeta.setDisplayName(" ");
            separator.setItemMeta(sepMeta);
        }
        for (int i = 0; i < 9; i++) {
            inv.setItem(i, separator);
        }

        UUID uuid = player.getUniqueId();
        HalloweenDataManager dataManager = questManager.getDataManager();

        List<HalloweenQuest> quests = questManager.getQuests();
        int slot = 9;
        for (HalloweenQuest quest : quests) {
            if (slot >= 27) break;

            boolean completed = dataManager.isCompleted(uuid, quest.getId());
            int progress = Math.min(dataManager.getProgress(uuid, quest.getId()), quest.getAmount());

            ItemStack item = new ItemStack(quest.getIcon());
            ItemMeta meta = item.getItemMeta();
            if (meta != null) {
                String status = completed ? "&a&l✔ TERMINEE" : "&e&l🎃 EN COURS";
                meta.setDisplayName(HexColor.translate(status + " &8- ") + quest.getName());

                List<String> lore = new ArrayList<>();
                lore.add(HexColor.translate("&7Progression : &f" + progress + "&7/&f" + quest.getAmount()));
                lore.add(HexColor.translate("&7Recompense : &6" + quest.getRewardKeys() + " cle(s) Halloween"));
                if (completed) {
                    lore.add("");
                    lore.add(HexColor.translate("&aDeja obtenue !"));
                }
                meta.setLore(lore);

                if (completed) {
                    meta.addEnchant(Enchantment.LUCK, 1, true);
                    meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
                }

                item.setItemMeta(meta);
            }

            inv.setItem(slot, item);
            slot++;
        }

        return inv;
    }
}
