package fr.block2box.listeners;

import fr.block2box.crates.CratePreviewHolder;
import fr.block2box.halloween.HalloweenGUIHolder;
import fr.block2box.invest.InvestGUIHolder;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.InventoryHolder;

public class GUIClickListener implements Listener {

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        InventoryHolder holder = event.getInventory().getHolder();
        if (holder instanceof CratePreviewHolder || holder instanceof InvestGUIHolder || holder instanceof HalloweenGUIHolder) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        InventoryHolder holder = event.getInventory().getHolder();
        if (holder instanceof CratePreviewHolder || holder instanceof InvestGUIHolder || holder instanceof HalloweenGUIHolder) {
            event.setCancelled(true);
        }
    }
}
