package fr.block2box.commands;

import fr.block2box.config.ConfigManager;
import fr.block2box.halloween.HalloweenGUI;
import fr.block2box.halloween.HalloweenQuestManager;
import fr.block2box.util.HexColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/**
 * Ouvre le GUI listant les 8 quetes Halloween du joueur et leur progression.
 */
public class HalloweenCommand implements CommandExecutor {

    private final ConfigManager configManager;
    private final HalloweenQuestManager questManager;

    public HalloweenCommand(ConfigManager configManager, HalloweenQuestManager questManager) {
        this.configManager = configManager;
        this.questManager = questManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(configManager.prefix() + configManager.message("player-only"));
            return true;
        }

        if (!questManager.isSeasonEnabled()) {
            player.sendMessage(configManager.prefix() + HexColor.translate(
                    "&cLa saison Halloween n'est pas active pour le moment."));
            return true;
        }

        player.openInventory(HalloweenGUI.build(player, questManager));
        return true;
    }
}
