package fr.block2box.commands;

import fr.block2box.config.ConfigManager;
import fr.block2box.util.HexColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;

import java.util.List;

/**
 * Affiche au joueur la liste des sites de vote configures (section
 * "vote-links" de config.yml). Les liens sont detectes et rendus cliquables
 * automatiquement par le client Minecraft, pas besoin de composants a part.
 */
public class VoteCommand implements CommandExecutor {

    private final ConfigManager configManager;

    public VoteCommand(ConfigManager configManager) {
        this.configManager = configManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        ConfigurationSection section = configManager.get().getConfigurationSection("vote-links");
        if (section == null || !section.getBoolean("enabled", true)) {
            sender.sendMessage(configManager.prefix() + HexColor.translate("&cLes liens de vote ne sont pas configures pour le moment."));
            return true;
        }

        String header = section.getString("header", "");
        if (header != null && !header.isBlank()) {
            sender.sendMessage(HexColor.translate(header));
        }

        List<String> sites = section.getStringList("sites");
        if (sites.isEmpty()) {
            sender.sendMessage(configManager.prefix() + HexColor.translate("&7Aucun site de vote configure pour le moment."));
        } else {
            for (String line : sites) {
                sender.sendMessage(HexColor.translate(line));
            }
        }

        String footer = section.getString("footer", "");
        if (footer != null && !footer.isBlank()) {
            sender.sendMessage(HexColor.translate(footer));
        }

        return true;
    }
}
