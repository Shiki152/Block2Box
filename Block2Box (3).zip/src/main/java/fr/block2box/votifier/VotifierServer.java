package fr.block2box.votifier;

import fr.block2box.config.ConfigManager;
import org.bukkit.plugin.Plugin;

import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Implementation "maison" du protocole Votifier, compatible avec les votes
 * envoyes en V1 (bloc RSA 256 octets) ou en V2 / NuVotifier (JSON signe HMAC-SHA256),
 * ce qui couvre la grande majorite des sites de vote (Top-Serveurs, Serveur-Prive, etc).
 */
public class VotifierServer {

    private final Plugin plugin;
    private final ConfigManager configManager;
    private final RSAKeyUtil rsaKeyUtil;
    private final VoteHandler voteHandler;

    private ServerSocket serverSocket;
    private Thread acceptThread;
    private final AtomicBoolean running = new AtomicBoolean(false);

    public VotifierServer(Plugin plugin, ConfigManager configManager, RSAKeyUtil rsaKeyUtil, VoteHandler voteHandler) {
        this.plugin = plugin;
        this.configManager = configManager;
        this.rsaKeyUtil = rsaKeyUtil;
        this.voteHandler = voteHandler;
    }

    public void start() {
        if (!configManager.get().getBoolean("votifier.enabled", true)) {
            plugin.getLogger().info("[Block2Box] Module votifier desactive dans config.yml (votifier.enabled: false).");
            return;
        }

        ensureTokenGenerated();

        String host = configManager.get().getString("votifier.host", "0.0.0.0");
        int port = configManager.get().getInt("votifier.port", 8192);

        try {
            serverSocket = new ServerSocket();
            serverSocket.setReuseAddress(true);
            serverSocket.bind(new InetSocketAddress(host, port));
            running.set(true);

            acceptThread = new Thread(this::acceptLoop, "Block2Box-Votifier-Accept");
            acceptThread.setDaemon(true);
            acceptThread.start();

            plugin.getLogger().info("[Block2Box] Serveur votifier demarre sur " + host + ":" + port + " (V1 + V2 compatibles).");
        } catch (IOException e) {
            plugin.getLogger().severe("[Block2Box] Impossible de demarrer le serveur votifier sur le port " + port + " : " + e.getMessage());
        }
    }

    public void stop() {
        running.set(false);
        try {
            if (serverSocket != null && !serverSocket.isClosed()) {
                serverSocket.close();
            }
        } catch (IOException ignored) {
        }
        if (acceptThread != null) {
            acceptThread.interrupt();
        }
    }

    private void ensureTokenGenerated() {
        String token = configManager.get().getString("votifier.token", "");
        if (token == null || token.isBlank() || token.startsWith("CHANGE_ME")) {
            // Chaine aleatoire opaque, sans prefixe : le prefixe "v1:" precedemment utilise ici
            // pretait a confusion avec le protocole V1 (ce token ne sert qu'au V2/NuVotifier).
            String generated = (UUID.randomUUID().toString() + UUID.randomUUID().toString()).replace("-", "");
            configManager.get().set("votifier.token", generated);
            configManager.save();
            plugin.getLogger().info("[Block2Box] Token votifier V2 auto-genere et sauvegarde dans config.yml.");
        }
    }

    private void acceptLoop() {
        while (running.get()) {
            try {
                Socket socket = serverSocket.accept();
                Thread handler = new Thread(() -> handleConnection(socket), "Block2Box-Votifier-Conn");
                handler.setDaemon(true);
                handler.start();
            } catch (IOException e) {
                if (running.get()) {
                    plugin.getLogger().warning("[Block2Box] Erreur d'acceptation votifier : " + e.getMessage());
                }
            }
        }
    }

    private void handleConnection(Socket socket) {
        try {
            socket.setSoTimeout(4000);
            String challenge = UUID.randomUUID().toString().replace("-", "");

            OutputStream out = socket.getOutputStream();
            InputStream in = socket.getInputStream();

            String greeting = "VOTIFIER 2 " + challenge + "\n";
            out.write(greeting.getBytes(StandardCharsets.UTF_8));
            out.flush();

            byte[] payload = readAllAvailable(in);
            if (payload.length == 0) {
                socket.close();
                return;
            }

            int rsaBlockSize = 256; // RSA 2048 bits => bloc chiffre de 256 octets

            if (payload.length == rsaBlockSize) {
                handleV1(payload);
            } else if (payload.length > 2) {
                handleV2(payload, challenge, out);
            } else {
                if (configManager.get().getBoolean("votifier.debug", false)) {
                    plugin.getLogger().warning("[Block2Box] Paquet votifier non reconnu (" + payload.length + " octets).");
                }
            }
        } catch (Exception e) {
            if (configManager.get().getBoolean("votifier.debug", false)) {
                plugin.getLogger().warning("[Block2Box] Erreur de traitement d'une connexion votifier : " + e.getMessage());
            }
        } finally {
            try {
                socket.close();
            } catch (IOException ignored) {
            }
        }
    }

    private byte[] readAllAvailable(InputStream in) throws IOException {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        byte[] tmp = new byte[1024];
        try {
            int read;
            while ((read = in.read(tmp)) != -1) {
                buffer.write(tmp, 0, read);
                if (buffer.size() > 8192) break; // securite anti-flood
                if (in.available() == 0) {
                    // Petite pause pour laisser le temps a d'eventuels octets restants d'arriver
                    try {
                        Thread.sleep(30);
                    } catch (InterruptedException ignored) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                    if (in.available() == 0) break;
                }
            }
        } catch (SocketTimeoutException ignored) {
            // Normal si le client a fini d'envoyer sans fermer la socket
        }
        return buffer.toByteArray();
    }

    // ================= Protocole V1 (bloc RSA) =================

    private void handleV1(byte[] block) {
        try {
            Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            cipher.init(Cipher.DECRYPT_MODE, rsaKeyUtil.getKeyPair().getPrivate());
            byte[] decrypted = cipher.doFinal(block);
            String text = new String(decrypted, StandardCharsets.UTF_8);
            String[] lines = text.split("\n");

            if (lines.length < 5 || !lines[0].trim().equalsIgnoreCase("VOTE")) {
                plugin.getLogger().warning("[Block2Box] Vote V1 recu mais mal forme, ignore.");
                return;
            }

            String serviceName = lines[1].trim();
            String username = lines[2].trim();
            String address = lines[3].trim();
            String timestamp = lines[4].trim();

            voteHandler.handleVote(serviceName, username, address, timestamp, "V1");
        } catch (Exception e) {
            plugin.getLogger().warning("[Block2Box] Impossible de dechiffrer un vote V1 (cle publique incorrecte cote site de vote ?) : " + e.getMessage());
        }
    }

    // ================= Protocole V2 (NuVotifier / JSON + HMAC) =================

    private void handleV2(byte[] raw, String expectedChallenge, OutputStream out) throws IOException {
        int declaredLength = ((raw[0] & 0xFF) << 8) | (raw[1] & 0xFF);
        int available = raw.length - 2;

        String jsonEnvelope;
        if (declaredLength == available) {
            jsonEnvelope = new String(raw, 2, available, StandardCharsets.UTF_8);
        } else {
            // Certains clients n'envoient pas le prefixe de longueur exactement comme attendu :
            // on retente en interpretant tout le buffer comme JSON brut.
            jsonEnvelope = new String(raw, StandardCharsets.UTF_8);
        }

        String payloadStr = extractField(jsonEnvelope, "payload");
        String signature = extractField(jsonEnvelope, "signature");

        if (payloadStr == null || signature == null) {
            writeV2Error(out, "malformed_request", "Requete V2 illisible.");
            return;
        }

        String token = configManager.get().getString("votifier.token", "");
        boolean validSignature = verifyHmac(payloadStr, signature, token);

        if (!validSignature) {
            writeV2Error(out, "invalid_signature", "Token invalide.");
            plugin.getLogger().warning("[Block2Box] Vote V2 rejete : signature HMAC invalide (token incorrect cote site de vote).");
            return;
        }

        String serviceName = extractField(payloadStr, "serviceName");
        String username = extractField(payloadStr, "username");
        String address = extractField(payloadStr, "address");
        String timestamp = extractField(payloadStr, "timestamp");
        String challenge = extractField(payloadStr, "challenge");

        if (challenge == null || !challenge.equals(expectedChallenge)) {
            writeV2Error(out, "invalid_challenge", "Challenge invalide ou rejeu detecte.");
            return;
        }

        writeV2Success(out);
        voteHandler.handleVote(serviceName, username, address, timestamp, "V2/NuVotifier");
    }

    private boolean verifyHmac(String payload, String base64Signature, String token) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(token.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
            byte[] computed = mac.doFinal(payload.getBytes(StandardCharsets.UTF_8));
            byte[] provided = Base64.getDecoder().decode(base64Signature);
            return MessageDigest.isEqual(computed, provided);
        } catch (Exception e) {
            return false;
        }
    }

    private String extractField(String json, String field) {
        if (json == null) return null;
        // Le groupe capture gere les guillemets echappes (\") : indispensable pour le
        // champ "payload" qui contient du JSON imbrique serialise sous forme de chaine.
        Pattern pattern = Pattern.compile("\"" + field + "\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"");
        Matcher matcher = pattern.matcher(json);
        if (matcher.find()) {
            return unescapeJson(matcher.group(1));
        }
        return null;
    }

    private String unescapeJson(String s) {
        return s.replace("\\\"", "\"").replace("\\\\", "\\").replace("\\/", "/");
    }

    private void writeV2Success(OutputStream out) throws IOException {
        String json = "{\"status\":\"ok\"}";
        out.write(json.getBytes(StandardCharsets.UTF_8));
        out.flush();
    }

    private void writeV2Error(OutputStream out, String cause, String error) throws IOException {
        String json = "{\"status\":\"error\",\"cause\":\"" + cause + "\",\"error\":\"" + error + "\"}";
        out.write(json.getBytes(StandardCharsets.UTF_8));
        out.flush();
    }
}
