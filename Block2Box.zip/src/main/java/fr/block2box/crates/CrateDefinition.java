package fr.block2box.crates;

import org.bukkit.Material;

import java.util.List;

/**
 * Represente une caisse chargee depuis /crates/<id>.yml
 */
public class CrateDefinition {

    public enum KeyType {
        VIRTUAL, PHYSICAL
    }

    private final String id;
    private final String name;
    private final String displayName;
    private final Material block;
    private final KeyType keyType;
    private final boolean obtainable;

    private final boolean hologramEnabled;
    private final List<String> hologramLines;

    private final String previewTitle;
    private final int previewSize;

    private final List<RewardDefinition> rewards;

    public CrateDefinition(String id, String name, String displayName, Material block, KeyType keyType,
                            boolean obtainable, boolean hologramEnabled, List<String> hologramLines,
                            String previewTitle, int previewSize, List<RewardDefinition> rewards) {
        this.id = id;
        this.name = name;
        this.displayName = displayName;
        this.block = block;
        this.keyType = keyType;
        this.obtainable = obtainable;
        this.hologramEnabled = hologramEnabled;
        this.hologramLines = hologramLines;
        this.previewTitle = previewTitle;
        this.previewSize = previewSize;
        this.rewards = rewards;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDisplayName() {
        return displayName;
    }

    public Material getBlock() {
        return block;
    }

    public KeyType getKeyType() {
        return keyType;
    }

    public boolean isObtainable() {
        return obtainable;
    }

    public boolean isHologramEnabled() {
        return hologramEnabled;
    }

    public List<String> getHologramLines() {
        return hologramLines;
    }

    public String getPreviewTitle() {
        return previewTitle;
    }

    public int getPreviewSize() {
        return previewSize;
    }

    public List<RewardDefinition> getRewards() {
        return rewards;
    }

    public double totalChance() {
        double total = 0;
        for (RewardDefinition reward : rewards) {
            total += reward.getChance();
        }
        return total;
    }
}
