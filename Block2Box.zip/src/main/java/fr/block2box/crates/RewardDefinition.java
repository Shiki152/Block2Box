package fr.block2box.crates;

import org.bukkit.inventory.ItemStack;

import java.util.List;

/**
 * Represente une recompense possible d'une caisse (une ligne de "rewards:" dans le YML).
 */
public class RewardDefinition {

    private final String id;
    private final double chance;
    private final String rarity;
    private final ItemStack displayItem;
    private final List<String> commands;
    private final String giveKeyCrate;
    private final int giveKeyAmount;
    private final boolean broadcast;
    private final String broadcastMessage;

    public RewardDefinition(String id, double chance, String rarity, ItemStack displayItem,
                             List<String> commands, String giveKeyCrate, int giveKeyAmount,
                             boolean broadcast, String broadcastMessage) {
        this.id = id;
        this.chance = chance;
        this.rarity = rarity;
        this.displayItem = displayItem;
        this.commands = commands;
        this.giveKeyCrate = giveKeyCrate;
        this.giveKeyAmount = giveKeyAmount;
        this.broadcast = broadcast;
        this.broadcastMessage = broadcastMessage;
    }

    public String getId() {
        return id;
    }

    public double getChance() {
        return chance;
    }

    public String getRarity() {
        return rarity;
    }

    public ItemStack getDisplayItem() {
        return displayItem.clone();
    }

    public List<String> getCommands() {
        return commands;
    }

    public boolean hasGiveKey() {
        return giveKeyCrate != null && !giveKeyCrate.isEmpty() && giveKeyAmount > 0;
    }

    public String getGiveKeyCrate() {
        return giveKeyCrate;
    }

    public int getGiveKeyAmount() {
        return giveKeyAmount;
    }

    public boolean isBroadcast() {
        return broadcast;
    }

    public String getBroadcastMessage() {
        return broadcastMessage;
    }
}
