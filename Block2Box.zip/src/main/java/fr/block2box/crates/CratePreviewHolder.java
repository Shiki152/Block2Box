package fr.block2box.crates;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public class CratePreviewHolder implements InventoryHolder {

    private final String crateId;
    private Inventory inventory;

    public CratePreviewHolder(String crateId) {
        this.crateId = crateId;
    }

    public String getCrateId() {
        return crateId;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }
}
