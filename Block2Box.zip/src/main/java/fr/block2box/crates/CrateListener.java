package fr.block2box.crates;

import fr.block2box.config.ConfigManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;

public class CrateListener implements Listener {

    private final CrateManager crateManager;
    private final ConfigManager configManager;

    public CrateListener(CrateManager crateManager, ConfigManager configManager) {
        this.crateManager = crateManager;
        this.configManager = configManager;
    }

    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != null && event.getHand() != EquipmentSlot.HAND) {
            return; // evite le double-declenchement main principale / secondaire
        }
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK || event.getClickedBlock() == null) {
            return;
        }

        String crateId = crateManager.getCrateIdAt(event.getClickedBlock().getLocation());
        if (crateId == null) {
            return;
        }

        event.setCancelled(true);
        Player player = event.getPlayer();

        if (!player.hasPermission("block2box.use")) {
            player.sendMessage(configManager.prefix() + configManager.message("no-permission"));
            return;
        }

        CrateDefinition def = crateManager.getCrate(crateId);
        if (def == null) {
            return;
        }

        if (player.isSneaking()) {
            // Shift + clic droit = tentative d'ouverture reelle de la caisse
            CrateManager.OpenResult result = crateManager.openCrate(player, crateId);
            switch (result) {
                case NO_KEY_VIRTUAL -> player.sendMessage(configManager.prefix()
                        + configManager.message("no-key-virtual").replace("%crate%", def.getDisplayName()));
                case NO_KEY_PHYSICAL -> player.sendMessage(configManager.prefix()
                        + configManager.message("no-key-physical").replace("%crate%", def.getDisplayName()));
                case UNKNOWN_CRATE -> player.sendMessage(configManager.prefix() + configManager.message("crate-not-found").replace("%crate%", crateId));
                case SUCCESS -> {
                    // message deja envoye dans CrateManager#giveReward
                }
            }
        } else {
            // Simple clic droit = apercu du contenu de la caisse (aucune cle consommee)
            player.openInventory(PreviewGUI.build(def));
        }
    }
}
