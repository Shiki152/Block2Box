package fr.block2box.crates;

import fr.block2box.config.ConfigManager;
import fr.block2box.util.FileUtil;
import fr.block2box.util.HexColor;
import fr.block2box.util.ItemBuilder;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.logging.Logger;

public class CrateManager {

    public static final String[] CRATE_IDS = {"vote", "legendaire", "mythique"};

    private final Plugin plugin;
    private final ConfigManager configManager;
    private final KeyManager keyManager;
    private final Random random = new Random();

    private final Map<String, CrateDefinition> crates = new LinkedHashMap<>();
    // "world;x;y;z" -> crateId
    private final Map<String, String> locations = new HashMap<>();
    // "world;x;y;z" -> UUID de l'entite TextDisplay affichant l'hologramme
    private final Map<String, UUID> hologramEntities = new HashMap<>();

    private File locationsFile;

    public CrateManager(Plugin plugin, ConfigManager configManager, KeyManager keyManager) {
        this.plugin = plugin;
        this.configManager = configManager;
        this.keyManager = keyManager;
    }

    // ================= Chargement =================

    public void loadAll() {
        loadCrateDefinitions();
        keyManager.loadAll(CRATE_IDS);
        loadLocations();
        refreshAllHolograms();
    }

    public void reloadAll() {
        removeAllHolograms();
        crates.clear();
        loadCrateDefinitions();
        keyManager.reloadAll();
        refreshAllHolograms();
    }

    private void loadCrateDefinitions() {
        File cratesDir = new File(plugin.getDataFolder(), "crates");
        FileUtil.ensureDir(cratesDir);

        for (String id : CRATE_IDS) {
            File file = new File(cratesDir, id + ".yml");
            FileUtil.copyDefault(plugin, "crates/" + id + ".yml", file);
            YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
            CrateDefinition def = parseCrate(id, cfg);
            if (def != null) {
                crates.put(id, def);
            }
        }
    }

    private CrateDefinition parseCrate(String id, YamlConfiguration cfg) {
        ConfigurationSection crateSection = cfg.getConfigurationSection("crate");
        if (crateSection == null) {
            plugin.getLogger().severe("[Block2Box] Section 'crate' manquante dans crates/" + id + ".yml");
            return null;
        }

        String name = crateSection.getString("name", id);
        String displayName = crateSection.getString("display-name", name);
        String blockName = crateSection.getString("block", "CHEST").toUpperCase();
        Material block = Material.matchMaterial(blockName);
        if (block == null) {
            plugin.getLogger().warning("[Block2Box] Bloc invalide pour la caisse " + id + " : " + blockName + " -> CHEST utilise.");
            block = Material.CHEST;
        }

        CrateDefinition.KeyType keyType;
        try {
            keyType = CrateDefinition.KeyType.valueOf(crateSection.getString("key-type", "VIRTUAL").toUpperCase());
        } catch (IllegalArgumentException ex) {
            plugin.getLogger().warning("[Block2Box] key-type invalide pour " + id + ", VIRTUAL utilise par defaut.");
            keyType = CrateDefinition.KeyType.VIRTUAL;
        }

        boolean obtainable = crateSection.getBoolean("obtainable", true);

        ConfigurationSection hologramSection = cfg.getConfigurationSection("hologram");
        boolean hologramEnabled = hologramSection != null && hologramSection.getBoolean("enabled", true);
        List<String> hologramLines = hologramSection != null ? hologramSection.getStringList("lines") : new ArrayList<>();

        ConfigurationSection previewSection = cfg.getConfigurationSection("preview-gui");
        String previewTitle = previewSection != null ? previewSection.getString("title", "&8" + displayName) : "&8" + displayName;
        int previewSize = previewSection != null ? previewSection.getInt("size", 27) : 27;
        if (previewSize % 9 != 0 || previewSize < 9 || previewSize > 54) {
            previewSize = 27;
        }

        List<RewardDefinition> rewards = new ArrayList<>();
        List<?> rewardList = cfg.getList("rewards");
        if (rewardList != null) {
            for (Object obj : rewardList) {
                if (!(obj instanceof Map)) continue;
                @SuppressWarnings("unchecked")
                Map<String, Object> rawMap = (Map<String, Object>) obj;
                // createSection(path, map) convertit recursivement les Map imbriquees (ex: display-item)
                // en veritables ConfigurationSection, contrairement a set() qui garderait des LinkedHashMap brutes.
                YamlConfiguration wrapper = new YamlConfiguration();
                ConfigurationSection rewardSection = wrapper.createSection("reward", rawMap);
                RewardDefinition reward = parseReward(id, rewardSection);
                if (reward != null) {
                    rewards.add(reward);
                }
            }
        }

        return new CrateDefinition(id, name, HexColor.translate(displayName), block, keyType, obtainable,
                hologramEnabled, hologramLines, previewTitle, previewSize, rewards);
    }

    private RewardDefinition parseReward(String crateId, ConfigurationSection section) {
        String rewardId = section.getString("id", "reward_" + random.nextInt(999999));
        double chance = section.getDouble("chance", 0.0);
        String rarity = section.getString("rarity", "COMMUN");

        ConfigurationSection displaySection = section.getConfigurationSection("display-item");
        List<String> enchantLines = section.getStringList("enchantments");
        ItemStack item = ItemBuilder.fromSection(displaySection, enchantLines, plugin.getLogger());

        List<String> commands = section.getStringList("commands");

        String giveKey = section.getString("give-key", "");
        String giveKeyCrate = "";
        int giveKeyAmount = 0;
        if (giveKey != null && !giveKey.isBlank()) {
            String[] parts = giveKey.split(":");
            giveKeyCrate = parts[0].trim().toLowerCase();
            giveKeyAmount = parts.length > 1 ? parseIntSafe(parts[1].trim(), 1) : 1;

            // Garde-fou : la caisse Mythique n'est jamais distribuable automatiquement.
            if (!crateId.equalsIgnoreCase("mythique") && giveKeyCrate.equalsIgnoreCase("mythique")) {
                plugin.getLogger().warning("[Block2Box] Reward '" + rewardId + "' dans " + crateId
                        + ".yml tente de donner une cle Mythique automatiquement. Ceci est bloque : "
                        + "la caisse Mythique n'est distribuable que via /block2box givekey.");
                giveKeyCrate = "";
                giveKeyAmount = 0;
            }
        }

        boolean broadcast = section.getBoolean("broadcast", false);
        String broadcastMessage = section.getString("broadcast-message", "&e%player% &7a obtenu une recompense rare !");

        return new RewardDefinition(rewardId, chance, rarity, item, commands, giveKeyCrate, giveKeyAmount, broadcast, broadcastMessage);
    }

    private int parseIntSafe(String s, int def) {
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            return def;
        }
    }

    // ================= Emplacements des caisses =================

    private void loadLocations() {
        locationsFile = new File(plugin.getDataFolder(), "crates/locations.yml");
        if (!locationsFile.exists()) {
            FileUtil.ensureDir(locationsFile.getParentFile());
            try {
                locationsFile.createNewFile();
            } catch (IOException e) {
                plugin.getLogger().severe("[Block2Box] Impossible de creer locations.yml : " + e.getMessage());
            }
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(locationsFile);
        locations.clear();
        ConfigurationSection section = cfg.getConfigurationSection("locations");
        if (section != null) {
            for (String key : section.getKeys(false)) {
                locations.put(key, section.getString(key));
            }
        }
    }

    private void saveLocations() {
        YamlConfiguration cfg = new YamlConfiguration();
        for (Map.Entry<String, String> entry : locations.entrySet()) {
            cfg.set("locations." + entry.getKey(), entry.getValue());
        }
        try {
            cfg.save(locationsFile);
        } catch (IOException e) {
            plugin.getLogger().severe("[Block2Box] Impossible de sauvegarder locations.yml : " + e.getMessage());
        }
    }

    private String keyFor(Location loc) {
        return loc.getWorld().getName() + ";" + loc.getBlockX() + ";" + loc.getBlockY() + ";" + loc.getBlockZ();
    }

    public void setCrateLocation(Location loc, String crateId) {
        String key = keyFor(loc);
        locations.put(key, crateId);
        saveLocations();
        CrateDefinition def = crates.get(crateId);
        if (def != null) {
            loc.getBlock().setType(def.getBlock());
            spawnOrUpdateHologram(loc, def);
        }
    }

    public String getCrateIdAt(Location loc) {
        return locations.get(keyFor(loc));
    }

    // ================= Hologrammes =================

    private void refreshAllHolograms() {
        for (Map.Entry<String, String> entry : locations.entrySet()) {
            Location loc = parseLocationKey(entry.getKey());
            CrateDefinition def = crates.get(entry.getValue());
            if (loc != null && def != null) {
                spawnOrUpdateHologram(loc, def);
            }
        }
    }

    private Location parseLocationKey(String key) {
        String[] parts = key.split(";");
        if (parts.length != 4) return null;
        World world = Bukkit.getWorld(parts[0]);
        if (world == null) return null;
        try {
            int x = Integer.parseInt(parts[1]);
            int y = Integer.parseInt(parts[2]);
            int z = Integer.parseInt(parts[3]);
            return new Location(world, x + 0.5, y + 1.25, z + 0.5);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private void spawnOrUpdateHologram(Location blockLoc, CrateDefinition def) {
        if (!def.isHologramEnabled() || def.getHologramLines().isEmpty()) {
            return;
        }
        String key = keyFor(blockLoc);
        Location holoLoc = blockLoc.clone().add(0.5, 1.25, 0.5);
        if (blockLoc.getWorld() == null) return;

        UUID existingId = hologramEntities.get(key);
        TextDisplay display = null;
        if (existingId != null) {
            Entity e = Bukkit.getEntity(existingId);
            if (e instanceof TextDisplay td && !td.isDead()) {
                display = td;
            }
        }

        String text = String.join("\n", translateAll(def.getHologramLines()));

        if (display == null) {
            World world = blockLoc.getWorld();
            Entity spawned = world.spawnEntity(holoLoc, EntityType.TEXT_DISPLAY);
            if (spawned instanceof TextDisplay td) {
                display = td;
                hologramEntities.put(key, display.getUniqueId());
            }
        }

        if (display != null) {
            display.setBillboard(org.bukkit.entity.Display.Billboard.CENTER);
            display.setText(text);
            display.setSeeThrough(false);
            display.setShadowed(true);
            display.setPersistent(true);
        }
    }

    private List<String> translateAll(List<String> lines) {
        List<String> out = new ArrayList<>();
        for (String l : lines) out.add(HexColor.translate(l));
        return out;
    }

    private void removeAllHolograms() {
        for (UUID id : hologramEntities.values()) {
            Entity e = Bukkit.getEntity(id);
            if (e != null) e.remove();
        }
        hologramEntities.clear();
    }

    // ================= Acces aux definitions =================

    public CrateDefinition getCrate(String id) {
        return crates.get(id);
    }

    public boolean isValidCrate(String id) {
        return crates.containsKey(id.toLowerCase());
    }

    public Map<String, CrateDefinition> getAllCrates() {
        return crates;
    }

    // ================= Ouverture de caisse =================

    public enum OpenResult {
        SUCCESS, NO_KEY_VIRTUAL, NO_KEY_PHYSICAL, UNKNOWN_CRATE
    }

    public OpenResult openCrate(Player player, String crateId) {
        CrateDefinition def = crates.get(crateId.toLowerCase());
        if (def == null) return OpenResult.UNKNOWN_CRATE;

        if (def.getKeyType() == CrateDefinition.KeyType.VIRTUAL) {
            if (!keyManager.removeVirtualKeys(def.getId(), player.getUniqueId(), 1)) {
                return OpenResult.NO_KEY_VIRTUAL;
            }
        } else {
            if (!keyManager.consumePhysicalKey(player, def.getId())) {
                return OpenResult.NO_KEY_PHYSICAL;
            }
        }

        RewardDefinition reward = rollReward(def);
        if (reward == null) {
            return OpenResult.SUCCESS;
        }

        giveReward(player, def, reward);
        return OpenResult.SUCCESS;
    }

    private RewardDefinition rollReward(CrateDefinition def) {
        List<RewardDefinition> rewards = def.getRewards();
        if (rewards.isEmpty()) return null;

        double total = def.totalChance();
        if (total <= 0) {
            return rewards.get(random.nextInt(rewards.size()));
        }

        double roll = random.nextDouble() * total;
        double cumulative = 0;
        for (RewardDefinition reward : rewards) {
            cumulative += reward.getChance();
            if (roll <= cumulative) {
                return reward;
            }
        }
        return rewards.get(rewards.size() - 1);
    }

    private void giveReward(Player player, CrateDefinition def, RewardDefinition reward) {
        ItemStack item = reward.getDisplayItem();
        if (item != null && !item.getType().isAir()) {
            Map<Integer, ItemStack> overflow = player.getInventory().addItem(item);
            for (ItemStack leftover : overflow.values()) {
                player.getWorld().dropItemNaturally(player.getLocation(), leftover);
            }
        }

        for (String cmd : reward.getCommands()) {
            String parsed = cmd.replace("%player%", player.getName());
            Bukkit.getScheduler().runTask(plugin, () -> Bukkit.dispatchCommand(Bukkit.getConsoleSender(), parsed));
        }

        if (reward.hasGiveKey()) {
            giveKeyToPlayer(player, reward.getGiveKeyCrate(), reward.getGiveKeyAmount());
        }

        String opened = configManager.message("crate-opened").replace("%crate%", def.getDisplayName());
        player.sendMessage(configManager.prefix() + opened);

        if (reward.isBroadcast()) {
            String msg = HexColor.translate(reward.getBroadcastMessage()).replace("%player%", player.getName());
            Bukkit.broadcastMessage(configManager.prefix() + msg);
        }

        player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
    }

    /**
     * Donne une cle a un joueur en respectant le key-type de la caisse cible
     * (VIRTUAL -> solde interne, PHYSICAL -> item dans l'inventaire).
     * Utilise par les rewards "give-key" ainsi que par la commande /block2box givekey.
     */
    public boolean giveKeyToPlayer(Player onlinePlayer, String crateId, int amount) {
        CrateDefinition def = crates.get(crateId.toLowerCase());
        if (def == null) return false;

        if (def.getKeyType() == CrateDefinition.KeyType.VIRTUAL) {
            keyManager.addVirtualKeys(def.getId(), onlinePlayer.getUniqueId(), amount);
        } else {
            ItemStack keyItem = keyManager.buildPhysicalKeyItem(def.getId(), amount, plugin.getLogger());
            Map<Integer, ItemStack> overflow = onlinePlayer.getInventory().addItem(keyItem);
            for (ItemStack leftover : overflow.values()) {
                onlinePlayer.getWorld().dropItemNaturally(onlinePlayer.getLocation(), leftover);
            }
        }
        return true;
    }

    /**
     * Variante hors-ligne : ne fonctionne que pour les caisses en cle VIRTUAL
     * (le solde est stocke par UUID, independamment de la connexion du joueur).
     */
    public boolean giveKeyToOfflinePlayer(OfflinePlayer offlinePlayer, String crateId, int amount) {
        CrateDefinition def = crates.get(crateId.toLowerCase());
        if (def == null) return false;
        if (def.getKeyType() != CrateDefinition.KeyType.VIRTUAL) {
            return false;
        }
        keyManager.addVirtualKeys(def.getId(), offlinePlayer.getUniqueId(), amount);
        return true;
    }

    public KeyManager getKeyManager() {
        return keyManager;
    }

    public Logger logger() {
        return plugin.getLogger();
    }
}
