package fr.block2box.commands;

import fr.block2box.config.ConfigManager;
import fr.block2box.invest.InvestGUI;
import fr.block2box.invest.PlaytimeManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class InvestCommand implements CommandExecutor {

    private final ConfigManager configManager;
    private final PlaytimeManager playtimeManager;

    public InvestCommand(ConfigManager configManager, PlaytimeManager playtimeManager) {
        this.configManager = configManager;
        this.playtimeManager = playtimeManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(configManager.prefix() + configManager.message("player-only"));
            return true;
        }
        if (!player.hasPermission("block2box.use")) {
            player.sendMessage(configManager.prefix() + configManager.message("no-permission"));
            return true;
        }

        player.openInventory(InvestGUI.build(player, configManager, playtimeManager));
        return true;
    }
}
