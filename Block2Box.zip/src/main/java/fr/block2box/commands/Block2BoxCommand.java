package fr.block2box.commands;

import fr.block2box.Block2Box;
import fr.block2box.config.ConfigManager;
import fr.block2box.crates.CrateDefinition;
import fr.block2box.crates.CrateManager;
import fr.block2box.util.HexColor;
import fr.block2box.votifier.RSAKeyUtil;
import org.bukkit.Bukkit;
import org.bukkit.FluidCollisionMode;
import org.bukkit.OfflinePlayer;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Block2BoxCommand implements CommandExecutor, TabCompleter {

    private final Block2Box plugin;
    private final ConfigManager configManager;
    private final CrateManager crateManager;
    private final RSAKeyUtil rsaKeyUtil;

    public Block2BoxCommand(Block2Box plugin, ConfigManager configManager, CrateManager crateManager, RSAKeyUtil rsaKeyUtil) {
        this.plugin = plugin;
        this.configManager = configManager;
        this.crateManager = crateManager;
        this.rsaKeyUtil = rsaKeyUtil;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "givekey" -> handleGiveKey(sender, args);
            case "setcrate" -> handleSetCrate(sender, args);
            case "removecrate" -> handleRemoveCrate(sender);
            case "reload" -> handleReload(sender);
            case "keys" -> handleKeys(sender);
            case "votifier" -> handleVotifier(sender);
            default -> sendHelp(sender);
        }
        return true;
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(configManager.prefix() + HexColor.translate("&7Commandes disponibles :"));
        sender.sendMessage(HexColor.translate("&e/block2box givekey <joueur> <caisse> <montant>"));
        sender.sendMessage(HexColor.translate("&e/block2box setcrate <caisse>"));
        sender.sendMessage(HexColor.translate("&e/block2box removecrate"));
        sender.sendMessage(HexColor.translate("&e/block2box reload"));
        sender.sendMessage(HexColor.translate("&e/block2box keys"));
        sender.sendMessage(HexColor.translate("&e/block2box votifier"));
        sender.sendMessage(HexColor.translate("&e/invest"));
        sender.sendMessage(HexColor.translate("&e/vote"));
    }

    private void handleGiveKey(CommandSender sender, String[] args) {
        if (!sender.hasPermission("block2box.givekey")) {
            sender.sendMessage(configManager.prefix() + configManager.message("no-permission"));
            return;
        }
        if (args.length < 4) {
            sender.sendMessage(configManager.prefix() + HexColor.translate("&cUsage: /block2box givekey <joueur> <caisse> <montant>"));
            return;
        }

        String playerName = args[1];
        String crateId = args[2].toLowerCase();
        int amount;
        try {
            amount = Integer.parseInt(args[3]);
            if (amount <= 0) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            sender.sendMessage(configManager.prefix() + configManager.message("invalid-amount"));
            return;
        }

        if (!crateManager.isValidCrate(crateId)) {
            sender.sendMessage(configManager.prefix() + configManager.message("crate-not-found").replace("%crate%", crateId));
            return;
        }

        CrateDefinition def = crateManager.getCrate(crateId);
        Player online = Bukkit.getPlayerExact(playerName);

        boolean success;
        if (online != null) {
            success = crateManager.giveKeyToPlayer(online, crateId, amount);
            if (success) {
                online.sendMessage(configManager.prefix() + configManager.message("key-given")
                        .replace("%amount%", String.valueOf(amount))
                        .replace("%crate%", def.getDisplayName()));
            }
        } else {
            OfflinePlayer offline = Bukkit.getOfflinePlayer(playerName);
            success = crateManager.giveKeyToOfflinePlayer(offline, crateId, amount);
            if (success && def.getKeyType() == CrateDefinition.KeyType.PHYSICAL) {
                sender.sendMessage(configManager.prefix() + HexColor.translate(
                        "&7" + playerName + " est hors-ligne : la cle physique lui sera donnee automatiquement a sa prochaine connexion."));
            }
        }

        if (success) {
            sender.sendMessage(configManager.prefix() + configManager.message("key-received")
                    .replace("%player%", playerName)
                    .replace("%amount%", String.valueOf(amount))
                    .replace("%crate%", def.getDisplayName()));
        } else {
            sender.sendMessage(configManager.prefix() + configManager.message("player-not-found").replace("%player%", playerName));
        }
    }

    private void handleSetCrate(CommandSender sender, String[] args) {
        if (!sender.hasPermission("block2box.setcrate")) {
            sender.sendMessage(configManager.prefix() + configManager.message("no-permission"));
            return;
        }
        if (!(sender instanceof Player player)) {
            sender.sendMessage(configManager.prefix() + configManager.message("player-only"));
            return;
        }
        if (args.length < 2) {
            sender.sendMessage(configManager.prefix() + HexColor.translate("&cUsage: /block2box setcrate <caisse>"));
            return;
        }

        String crateId = args[1].toLowerCase();
        if (!crateManager.isValidCrate(crateId)) {
            sender.sendMessage(configManager.prefix() + configManager.message("crate-not-found").replace("%crate%", crateId));
            return;
        }

        Block target = player.getTargetBlockExact(6, FluidCollisionMode.NEVER);
        if (target == null || target.getType().isAir()) {
            sender.sendMessage(configManager.prefix() + HexColor.translate("&cRegardez le bloc que vous souhaitez transformer en caisse."));
            return;
        }

        crateManager.setCrateLocation(target.getLocation(), crateId);
        sender.sendMessage(configManager.prefix() + configManager.message("crate-set").replace("%crate%", crateManager.getCrate(crateId).getDisplayName()));
    }

    private void handleRemoveCrate(CommandSender sender) {
        if (!sender.hasPermission("block2box.setcrate")) {
            sender.sendMessage(configManager.prefix() + configManager.message("no-permission"));
            return;
        }
        if (!(sender instanceof Player player)) {
            sender.sendMessage(configManager.prefix() + configManager.message("player-only"));
            return;
        }

        Block target = player.getTargetBlockExact(6, FluidCollisionMode.NEVER);
        if (target == null || target.getType().isAir()) {
            sender.sendMessage(configManager.prefix() + HexColor.translate("&cRegardez le bloc de la caisse a supprimer."));
            return;
        }

        boolean removed = crateManager.removeCrateLocation(target.getLocation());
        if (removed) {
            sender.sendMessage(configManager.prefix() + HexColor.translate(
                    "&aCaisse et hologramme supprimes a cet emplacement. &7(le bloc lui-meme n'a pas ete change)"));
        } else {
            sender.sendMessage(configManager.prefix() + HexColor.translate("&cAucune caisse Block2Box n'est enregistree a cet emplacement."));
        }
    }

    private void handleReload(CommandSender sender) {
        if (!sender.hasPermission("block2box.reload")) {
            sender.sendMessage(configManager.prefix() + configManager.message("no-permission"));
            return;
        }
        configManager.reload();
        crateManager.reloadAll();
        sender.sendMessage(configManager.prefix() + configManager.message("reload-success"));
    }

    private void handleKeys(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(configManager.prefix() + configManager.message("player-only"));
            return;
        }
        List<CrateDefinition> virtualCrates = crateManager.getAllCrates().values().stream()
                .filter(def -> def.getKeyType() == CrateDefinition.KeyType.VIRTUAL)
                .collect(Collectors.toList());

        if (virtualCrates.isEmpty()) {
            sender.sendMessage(configManager.prefix() + HexColor.translate(
                    "&7Toutes les cles sont des objets physiques : regardez dans votre inventaire !"));
            return;
        }

        sender.sendMessage(configManager.prefix() + HexColor.translate("&7Vos cles virtuelles :"));
        for (CrateDefinition def : virtualCrates) {
            int amount = crateManager.getKeyManager().getVirtualKeys(def.getId(), player.getUniqueId());
            sender.sendMessage(HexColor.translate(" &8- " + def.getDisplayName() + " &7: &f" + amount));
        }
    }

    private void handleVotifier(CommandSender sender) {
        if (!sender.hasPermission("block2box.votifier")) {
            sender.sendMessage(configManager.prefix() + configManager.message("no-permission"));
            return;
        }

        boolean realVotifierPresent = fr.block2box.votifier.NuVotifierBridge.isAvailable();
        if (realVotifierPresent) {
            sender.sendMessage(configManager.prefix() + HexColor.translate(
                    "&aLe plugin NuVotifier (ou Votifier) est installe : Block2Box l'utilise directement."));
            sender.sendMessage(HexColor.translate(
                    "&7Configurez le port et les tokens dans &fplugins/NuVotifier/config.yml&7, pas ici."));
            sender.sendMessage(HexColor.translate(
                    "&7Les cles/token generes par Block2Box ci-dessous ne servent a rien tant que NuVotifier est installe."));
            sender.sendMessage(HexColor.translate("&8------------------------------------------"));
        }

        if (!configManager.get().getBoolean("votifier.enabled", true)) {
            sender.sendMessage(configManager.prefix() + HexColor.translate("&cLe module votifier est desactive dans config.yml."));
            return;
        }
        if (rsaKeyUtil.getKeyPair() == null) {
            sender.sendMessage(configManager.prefix() + HexColor.translate("&cLes cles RSA ne sont pas encore chargees."));
            return;
        }
        sender.sendMessage(configManager.prefix() + HexColor.translate("&6Port votifier : &f" + configManager.get().getInt("votifier.port", 8192)));
        sender.sendMessage(HexColor.translate("&8------------------------------------------"));
        sender.sendMessage(HexColor.translate("&6Cle publique RSA &7(a coller UNIQUEMENT si le site propose &fVotifier V1&7) :"));
        sender.sendMessage(HexColor.translate("&f" + rsaKeyUtil.getPublicKeyBase64()));
        sender.sendMessage(HexColor.translate("&8------------------------------------------"));
        sender.sendMessage(HexColor.translate("&6Token &7(a coller UNIQUEMENT si le site propose &fNuVotifier / V2&7) :"));
        sender.sendMessage(HexColor.translate("&f" + configManager.get().getString("votifier.token")));
        sender.sendMessage(HexColor.translate("&8------------------------------------------"));
        sender.sendMessage(HexColor.translate("&7Ne copiez qu'UNE seule des deux valeurs ci-dessus, celle que demande le site (jamais les deux)."));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> options = new ArrayList<>();
        if (args.length == 1) {
            options.addAll(List.of("givekey", "setcrate", "removecrate", "reload", "keys", "votifier"));
            return filter(options, args[0]);
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("givekey")) {
            return filter(Bukkit.getOnlinePlayers().stream().map(Player::getName).collect(Collectors.toList()), args[1]);
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("setcrate")) {
            return filter(new ArrayList<>(crateManager.getAllCrates().keySet()), args[1]);
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("givekey")) {
            return filter(new ArrayList<>(crateManager.getAllCrates().keySet()), args[2]);
        }
        if (args.length == 4 && args[0].equalsIgnoreCase("givekey")) {
            return filter(List.of("1", "5", "10"), args[3]);
        }
        return options;
    }

    private List<String> filter(List<String> options, String prefix) {
        return options.stream().filter(o -> o.toLowerCase().startsWith(prefix.toLowerCase())).collect(Collectors.toList());
    }
}
