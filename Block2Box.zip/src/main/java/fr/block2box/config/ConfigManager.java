package fr.block2box.config;

import fr.block2box.util.FileUtil;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.io.IOException;

/**
 * Charge et sauvegarde /plugins/Block2Box/config.yml
 */
public class ConfigManager {

    private final Plugin plugin;
    private final File configFile;
    private YamlConfiguration config;

    public ConfigManager(Plugin plugin) {
        this.plugin = plugin;
        this.configFile = new File(plugin.getDataFolder(), "config.yml");
    }

    public void load() {
        FileUtil.ensureDir(plugin.getDataFolder());
        FileUtil.copyDefault(plugin, "config.yml", configFile);
        config = YamlConfiguration.loadConfiguration(configFile);
    }

    public void reload() {
        config = YamlConfiguration.loadConfiguration(configFile);
    }

    public void save() {
        try {
            config.save(configFile);
        } catch (IOException e) {
            plugin.getLogger().severe("[Block2Box] Impossible de sauvegarder config.yml : " + e.getMessage());
        }
    }

    public YamlConfiguration get() {
        return config;
    }

    public String prefix() {
        return fr.block2box.util.HexColor.translate(config.getString("prefix", "&8[&6Block2Box&8]&r "));
    }

    public String message(String path) {
        String raw = config.getString("messages." + path, "&c" + path);
        return fr.block2box.util.HexColor.translate(raw);
    }
}
