package fr.block2box.votifier;

import fr.block2box.config.ConfigManager;
import fr.block2box.util.HexColor;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public class VoteHandler {

    private final Plugin plugin;
    private final ConfigManager configManager;
    private final AntiSpamManager antiSpamManager;
    private final VoteLogger voteLogger;

    public VoteHandler(Plugin plugin, ConfigManager configManager, AntiSpamManager antiSpamManager, VoteLogger voteLogger) {
        this.plugin = plugin;
        this.configManager = configManager;
        this.antiSpamManager = antiSpamManager;
        this.voteLogger = voteLogger;
    }

    /**
     * Appele depuis le thread reseau du votifier. Bascule sur le thread principal
     * pour toute interaction avec l'API Bukkit.
     */
    public void handleVote(String serviceName, String username, String address, String timestamp) {
        boolean allowed = antiSpamManager.checkAndRecord(username, address);
        voteLogger.log(serviceName, username, address, allowed, allowed ? null : "anti-spam cooldown");

        if (configManager.get().getBoolean("votifier.debug", false)) {
            plugin.getLogger().info("[Block2Box] Vote recu : service=" + serviceName + " joueur=" + username
                    + " ip=" + address + " -> " + (allowed ? "ACCEPTE" : "BLOQUE (anti-spam)"));
        }

        if (!allowed) {
            return;
        }

        Bukkit.getScheduler().runTask(plugin, () -> {
            String rewardCommand = configManager.get().getString("votifier.reward-command",
                    "block2box givekey %player% vote 1").replace("%player%", username);
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), rewardCommand);

            Player player = Bukkit.getPlayerExact(username);
            if (player != null) {
                String rawMsg = configManager.get().getString("votifier.vote-message", "");
                if (rawMsg != null && !rawMsg.isBlank()) {
                    player.sendMessage(configManager.prefix() + HexColor.translate(rawMsg).replace("%player%", username));
                }
            }
        });
    }
}
