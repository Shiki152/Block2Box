package fr.block2box.votifier;

import fr.block2box.config.ConfigManager;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Ecrit chaque vote recu (accepte ou bloque par l'anti-spam) dans
 * /plugins/Block2Box/votifier/votes.log
 */
public class VoteLogger {

    private final Plugin plugin;
    private final File logFile;
    private static final DateTimeFormatter FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public VoteLogger(Plugin plugin, ConfigManager configManager) {
        this.plugin = plugin;
        String fileName = configManager.get().getString("votifier.log-file", "votes.log");
        this.logFile = new File(plugin.getDataFolder(), "votifier/" + fileName);
    }

    public synchronized void log(String serviceName, String username, String address, boolean accepted, String reason) {
        try {
            if (!logFile.getParentFile().exists()) {
                logFile.getParentFile().mkdirs();
            }
            try (FileWriter writer = new FileWriter(logFile, true)) {
                String line = String.format("[%s] service=%s joueur=%s ip=%s statut=%s%s%n",
                        LocalDateTime.now().format(FORMAT),
                        serviceName, username, address,
                        accepted ? "ACCEPTE" : "BLOQUE",
                        reason != null ? " (" + reason + ")" : "");
                writer.write(line);
            }
        } catch (IOException e) {
            plugin.getLogger().warning("[Block2Box] Impossible d'ecrire dans votes.log : " + e.getMessage());
        }
    }
}
