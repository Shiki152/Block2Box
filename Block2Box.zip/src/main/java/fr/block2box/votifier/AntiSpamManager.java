package fr.block2box.votifier;

import fr.block2box.config.ConfigManager;
import fr.block2box.util.FileUtil;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Empeche un meme joueur (par pseudo et/ou IP, selon la config) de
 * declencher plusieurs recompenses de vote en moins de X heures.
 * Persiste dans /plugins/Block2Box/votifier/antispam.yml
 */
public class AntiSpamManager {

    private final Plugin plugin;
    private final ConfigManager configManager;
    private final File file;
    private YamlConfiguration config;

    public AntiSpamManager(Plugin plugin, ConfigManager configManager) {
        this.plugin = plugin;
        this.configManager = configManager;
        this.file = new File(plugin.getDataFolder(), "votifier/antispam.yml");
    }

    public void load() {
        FileUtil.ensureDir(file.getParentFile());
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                plugin.getLogger().severe("[Block2Box] Impossible de creer antispam.yml : " + e.getMessage());
            }
        }
        config = YamlConfiguration.loadConfiguration(file);
    }

    private void save() {
        try {
            config.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("[Block2Box] Impossible de sauvegarder antispam.yml : " + e.getMessage());
        }
    }

    /**
     * Retourne true si le vote est autorise (pas de spam detecte). Met egalement a jour
     * l'horodatage du dernier vote accepte pour le/les identifiants concernes.
     */
    public synchronized boolean checkAndRecord(String username, String ip) {
        boolean enabled = configManager.get().getBoolean("votifier.anti-spam.enabled", true);
        if (!enabled) {
            return true;
        }

        long cooldownMillis = TimeUnit.HOURS.toMillis(configManager.get().getLong("votifier.anti-spam.cooldown-hours", 3));
        List<String> checkBy = configManager.get().getStringList("votifier.anti-spam.check-by");
        boolean checkName = checkBy.isEmpty() || checkBy.contains("NAME");
        boolean checkIp = checkBy.isEmpty() || checkBy.contains("IP");

        long now = System.currentTimeMillis();

        if (checkName && username != null) {
            long last = config.getLong("names." + sanitize(username), 0L);
            if (now - last < cooldownMillis) {
                return false;
            }
        }
        if (checkIp && ip != null) {
            long last = config.getLong("ips." + sanitize(ip), 0L);
            if (now - last < cooldownMillis) {
                return false;
            }
        }

        if (checkName && username != null) {
            config.set("names." + sanitize(username), now);
        }
        if (checkIp && ip != null) {
            config.set("ips." + sanitize(ip), now);
        }
        save();
        return true;
    }

    private String sanitize(String s) {
        return s.replace(".", "_").replace(" ", "_");
    }
}
