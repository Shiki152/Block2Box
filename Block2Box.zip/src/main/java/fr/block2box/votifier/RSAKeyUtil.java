package fr.block2box.votifier;

import org.bukkit.plugin.Plugin;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

/**
 * Genere (au premier demarrage) ou charge la paire de cles RSA 2048 bits
 * utilisee par le module votifier interne, stockees en DER brut dans
 * /plugins/Block2Box/votifier/public.key et private.key (format classique
 * compatible avec l'ecosysteme Votifier historique).
 */
public class RSAKeyUtil {

    private final Plugin plugin;
    private final File folder;
    private final File publicFile;
    private final File privateFile;

    private KeyPair keyPair;

    public RSAKeyUtil(Plugin plugin) {
        this.plugin = plugin;
        this.folder = new File(plugin.getDataFolder(), "votifier");
        this.publicFile = new File(folder, "public.key");
        this.privateFile = new File(folder, "private.key");
    }

    public void loadOrGenerate() throws NoSuchAlgorithmException, IOException, InvalidKeySpecException {
        if (!folder.exists()) folder.mkdirs();

        if (publicFile.exists() && privateFile.exists()) {
            PublicKey pub = loadPublicKey();
            PrivateKey priv = loadPrivateKey();
            keyPair = new KeyPair(pub, priv);
            plugin.getLogger().info("[Block2Box] Cles RSA du votifier chargees depuis /votifier/.");
        } else {
            KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
            generator.initialize(2048);
            keyPair = generator.generateKeyPair();

            try (FileOutputStream out = new FileOutputStream(publicFile)) {
                out.write(keyPair.getPublic().getEncoded());
            }
            try (FileOutputStream out = new FileOutputStream(privateFile)) {
                out.write(keyPair.getPrivate().getEncoded());
            }
            plugin.getLogger().info("[Block2Box] Nouvelle paire de cles RSA 2048 generee dans /votifier/.");
        }
    }

    private PublicKey loadPublicKey() throws IOException, NoSuchAlgorithmException, InvalidKeySpecException {
        byte[] bytes = readAll(publicFile);
        X509EncodedKeySpec spec = new X509EncodedKeySpec(bytes);
        return KeyFactory.getInstance("RSA").generatePublic(spec);
    }

    private PrivateKey loadPrivateKey() throws IOException, NoSuchAlgorithmException, InvalidKeySpecException {
        byte[] bytes = readAll(privateFile);
        PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(bytes);
        return KeyFactory.getInstance("RSA").generatePrivate(spec);
    }

    private byte[] readAll(File file) throws IOException {
        try (FileInputStream in = new FileInputStream(file)) {
            return in.readAllBytes();
        }
    }

    public KeyPair getKeyPair() {
        return keyPair;
    }

    public String getPublicKeyBase64() {
        return Base64.getEncoder().encodeToString(keyPair.getPublic().getEncoded());
    }
}
