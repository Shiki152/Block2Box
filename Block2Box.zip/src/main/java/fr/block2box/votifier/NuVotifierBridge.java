package fr.block2box.votifier;

import com.vexsoftware.votifier.model.Vote;
import com.vexsoftware.votifier.model.VotifierEvent;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;

/**
 * Pont vers le VRAI plugin NuVotifier (ou l'original Votifier), quand il est
 * installe sur le serveur. Beaucoup plus fiable que notre implementation
 * reseau maison (VotifierServer) : NuVotifier gere lui-meme tout le protocole
 * (V1 RSA + V2 HMAC, anti-rejeu, etc.), deja teste par des milliers de
 * serveurs. Voir Block2Box#onEnable : si NuVotifier/Votifier est detecte,
 * ce pont est utilise A LA PLACE de VotifierServer (jamais les deux en meme
 * temps, pour eviter un conflit de port et un double traitement des votes).
 */
public class NuVotifierBridge implements Listener {

    private final VoteHandler voteHandler;

    public NuVotifierBridge(VoteHandler voteHandler) {
        this.voteHandler = voteHandler;
    }

    @EventHandler(priority = EventPriority.NORMAL)
    public void onVotifierEvent(VotifierEvent event) {
        Vote vote = event.getVote();
        if (vote == null) return;

        voteHandler.handleVote(
                vote.getServiceName(),
                vote.getUsername(),
                vote.getAddress(),
                vote.getTimeStamp(),
                "NuVotifier (plugin officiel)"
        );
    }
}
