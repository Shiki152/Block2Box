package fr.block2box.votifier;

import org.bukkit.Bukkit;
import org.bukkit.event.Event;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.plugin.EventExecutor;
import org.bukkit.plugin.Plugin;

import java.lang.reflect.Method;

/**
 * Pont vers le VRAI plugin NuVotifier (ou l'original Votifier), s'il est
 * installe sur le serveur. Beaucoup plus fiable que notre implementation
 * reseau maison (VotifierServer) : NuVotifier gere lui-meme tout le protocole
 * (V1 RSA + V2 HMAC, anti-rejeu, etc.).
 *
 * IMPORTANT : ce pont s'accroche a com.vexsoftware.votifier.model.VotifierEvent
 * PAR REFLEXION, sans jamais en dependre a la compilation. Ca evite tout
 * probleme de coordonnees Maven/JitPack pour un jar tiers (NuVotifier n'est
 * pas publie sur Maven Central, et les depots communautaires bougent), et ca
 * fonctionne avec n'importe quelle version de NuVotifier ou meme l'ancien
 * Votifier d'origine, tant que ces deux methodes/classes existent (stables
 * et documentees depuis des annees).
 *
 * Voir Block2Box#onEnable : si register(...) retourne true, VotifierServer
 * (notre serveur interne) n'est PAS demarre, pour eviter un conflit de port
 * et un double traitement des votes.
 */
public final class NuVotifierBridge {

    private NuVotifierBridge() {
    }

    /**
     * Vrai si la classe VotifierEvent est chargeable (NuVotifier ou Votifier installe),
     * sans s'enregistrer. Utilise pour l'affichage (ex: /block2box votifier).
     */
    public static boolean isAvailable() {
        try {
            Class.forName("com.vexsoftware.votifier.model.VotifierEvent");
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /**
     * Tente de s'enregistrer sur le VotifierEvent du vrai plugin. Retourne true
     * si l'enregistrement a reussi (le plugin est installe et l'API repond).
     */
    public static boolean register(Plugin plugin, VoteHandler voteHandler) {
        try {
            Class<?> eventClass = Class.forName("com.vexsoftware.votifier.model.VotifierEvent");
            Class<?> voteClass = Class.forName("com.vexsoftware.votifier.model.Vote");

            Method getVote = eventClass.getMethod("getVote");
            Method getServiceName = voteClass.getMethod("getServiceName");
            Method getUsername = voteClass.getMethod("getUsername");
            Method getAddress = voteClass.getMethod("getAddress");
            Method getTimeStamp = voteClass.getMethod("getTimeStamp");

            @SuppressWarnings("unchecked")
            Class<? extends Event> typedEventClass = (Class<? extends Event>) eventClass;

            EventExecutor executor = (listener, event) -> {
                try {
                    Object vote = getVote.invoke(event);
                    if (vote == null) return;
                    String service = String.valueOf(getServiceName.invoke(vote));
                    String username = String.valueOf(getUsername.invoke(vote));
                    String address = String.valueOf(getAddress.invoke(vote));
                    String timestamp = String.valueOf(getTimeStamp.invoke(vote));
                    voteHandler.handleVote(service, username, address, timestamp, "NuVotifier (plugin officiel)");
                } catch (Exception e) {
                    plugin.getLogger().warning("[Block2Box] Erreur en lisant un vote NuVotifier/Votifier : "
                            + e.getClass().getSimpleName() + " - " + e.getMessage());
                }
            };

            Listener dummyListener = new Listener() {
            };
            Bukkit.getPluginManager().registerEvent(typedEventClass, dummyListener, EventPriority.NORMAL, executor, plugin, true);
            return true;
        } catch (ClassNotFoundException e) {
            // NuVotifier/Votifier non installe : normal, on utilisera le serveur interne.
            return false;
        } catch (Exception e) {
            plugin.getLogger().warning("[Block2Box] NuVotifier/Votifier semble installe mais le branchement a echoue ("
                    + e.getClass().getSimpleName() + " - " + e.getMessage() + "). Utilisation du serveur interne a la place.");
            return false;
        }
    }
}
