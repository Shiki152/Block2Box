package fr.block2box.invest;

import fr.block2box.config.ConfigManager;
import fr.block2box.util.HexColor;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.UUID;

public class PlaytimeManager {

    private final Plugin plugin;
    private final ConfigManager configManager;
    private final PlayerDataManager playerDataManager;

    private final Map<UUID, Long> lastActivity = new HashMap<>();
    private boolean placeholderApiAvailable;

    private static final long TICK_INTERVAL = 20L; // 1 seconde

    public PlaytimeManager(Plugin plugin, ConfigManager configManager, PlayerDataManager playerDataManager) {
        this.plugin = plugin;
        this.configManager = configManager;
        this.playerDataManager = playerDataManager;
    }

    public void start() {
        boolean wantsPapi = configManager.get().getBoolean("invest.use-placeholderapi", true);
        this.placeholderApiAvailable = wantsPapi && Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI");
        if (wantsPapi && !placeholderApiAvailable) {
            plugin.getLogger().info("[Block2Box] PlaceholderAPI non detecte : utilisation du compteur de playtime interne.");
        }

        Bukkit.getScheduler().runTaskTimer(plugin, this::tick, TICK_INTERVAL, TICK_INTERVAL);
    }

    private void tick() {
        boolean countAfk = configManager.get().getBoolean("invest.count-afk", false);

        for (Player player : Bukkit.getOnlinePlayers()) {
            if (!placeholderApiAvailable) {
                boolean active = countAfk || isActive(player);
                if (active) {
                    playerDataManager.addInternalSeconds(player.getUniqueId(), TICK_INTERVAL / 20L);
                }
            }
            checkMilestones(player);
        }
    }

    public void updateActivity(Player player) {
        lastActivity.put(player.getUniqueId(), System.currentTimeMillis());
    }

    private boolean isActive(Player player) {
        long threshold = configManager.get().getLong("invest.afk-threshold-seconds", 300L) * 1000L;
        Long last = lastActivity.get(player.getUniqueId());
        if (last == null) {
            return true; // pas encore de donnee, on considere actif par defaut
        }
        return (System.currentTimeMillis() - last) <= threshold;
    }

    /**
     * Temps de jeu total du joueur, en heures (valeur decimale).
     */
    public double getPlaytimeHours(Player player) {
        if (placeholderApiAvailable) {
            try {
                String raw = me.clip.placeholderapi.PlaceholderAPI.setPlaceholders(player, "%statistic_play_one_minute%");
                long minutes = Long.parseLong(raw.replace(",", "").trim());
                return minutes / 60.0;
            } catch (Exception ex) {
                // Repli silencieux sur le compteur interne en cas de probleme de parsing/placeholder
            }
        }
        long seconds = playerDataManager.getInternalSeconds(player.getUniqueId());
        return seconds / 3600.0;
    }

    /**
     * Retourne les paliers configures, tries par heure croissante : heure -> section de config.
     */
    public TreeMap<Integer, ConfigurationSection> getMilestones() {
        TreeMap<Integer, ConfigurationSection> result = new TreeMap<>();
        ConfigurationSection root = configManager.get().getConfigurationSection("invest.playtime-rewards");
        if (root == null) return result;
        for (String key : root.getKeys(false)) {
            try {
                int hours = Integer.parseInt(key);
                ConfigurationSection section = root.getConfigurationSection(key);
                if (section != null) {
                    result.put(hours, section);
                }
            } catch (NumberFormatException ignored) {
            }
        }
        return result;
    }

    private void checkMilestones(Player player) {
        double hours = getPlaytimeHours(player);
        for (Map.Entry<Integer, ConfigurationSection> entry : getMilestones().entrySet()) {
            int milestoneHours = entry.getKey();
            if (hours + 1e-6 < milestoneHours) continue;
            if (playerDataManager.hasClaimed(player.getUniqueId(), milestoneHours)) continue;

            playerDataManager.addClaimedMilestone(player.getUniqueId(), milestoneHours);
            grant(player, entry.getValue(), milestoneHours);
        }
    }

    private void grant(Player player, ConfigurationSection section, int milestoneHours) {
        List<String> commands = section.getStringList("commands");
        for (String cmd : commands) {
            String parsed = cmd.replace("%player%", player.getName());
            Bukkit.getScheduler().runTask(plugin, () -> Bukkit.dispatchCommand(Bukkit.getConsoleSender(), parsed));
        }

        String displayName = HexColor.translate(section.getString("display-name", milestoneHours + "h"));
        player.sendMessage(configManager.prefix() + HexColor.translate("&aPalier atteint : &f" + displayName + " &a! Recompense distribuee."));
        player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.4f);

        if (section.getBoolean("broadcast", false)) {
            String msg = HexColor.translate(section.getString("broadcast-message", "&e%player% &7a atteint un nouveau palier de playtime !"))
                    .replace("%player%", player.getName());
            Bukkit.broadcastMessage(configManager.prefix() + msg);
        }
    }

    public PlayerDataManager getPlayerDataManager() {
        return playerDataManager;
    }

    public boolean isPlaceholderApiAvailable() {
        return placeholderApiAvailable;
    }
}
