package fr.block2box.invest;

import fr.block2box.config.ConfigManager;
import fr.block2box.util.HexColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public final class InvestGUI {

    private InvestGUI() {
    }

    public static Inventory build(Player player, ConfigManager configManager, PlaytimeManager playtimeManager) {
        int size = configManager.get().getInt("invest.gui-size", 45);
        if (size % 9 != 0 || size < 9 || size > 54) size = 45;

        String title = HexColor.translate(configManager.get().getString("invest.gui-title", "&8Investissement"));
        InvestGUIHolder holder = new InvestGUIHolder();
        Inventory inv = Bukkit.createInventory(holder, size, title);
        holder.setInventory(inv);

        double hours = playtimeManager.getPlaytimeHours(player);

        // Tete du joueur avec le temps de jeu total au centre-haut
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        ItemMeta headMeta = head.getItemMeta();
        if (headMeta instanceof SkullMeta skullMeta) {
            skullMeta.setOwningPlayer(player);
            skullMeta.setDisplayName(HexColor.translate("&e&l" + player.getName()));
            List<String> lore = new ArrayList<>();
            lore.add(HexColor.translate("&7Temps de jeu total :"));
            lore.add(HexColor.translate(String.format("&f%.1f heures", hours)));
            lore.add("");
            lore.add(HexColor.translate(playtimeManager.isPlaceholderApiAvailable()
                    ? "&8Source : PlaceholderAPI"
                    : "&8Source : compteur interne Block2Box"));
            skullMeta.setLore(lore);
            head.setItemMeta(skullMeta);
        }
        inv.setItem(4, head);

        // Vitre de separation
        ItemStack separator = new ItemStack(Material.LIGHT_BLUE_STAINED_GLASS_PANE);
        ItemMeta sepMeta = separator.getItemMeta();
        if (sepMeta != null) {
            sepMeta.setDisplayName(" ");
            separator.setItemMeta(sepMeta);
        }
        for (int i = 0; i < 9; i++) {
            if (i != 4) inv.setItem(i, separator);
        }

        TreeMap<Integer, ConfigurationSection> milestones = playtimeManager.getMilestones();
        int slot = 9;
        for (Map.Entry<Integer, ConfigurationSection> entry : milestones.entrySet()) {
            if (slot >= size) break;
            int milestoneHours = entry.getKey();
            ConfigurationSection section = entry.getValue();
            boolean claimed = playtimeManager.getPlayerDataManager().hasClaimed(player.getUniqueId(), milestoneHours);
            boolean unlocked = hours >= milestoneHours;

            String iconName = section.getString("icon", "CHEST").toUpperCase();
            Material icon = Material.matchMaterial(iconName);
            if (icon == null) icon = Material.CHEST;

            ItemStack item = new ItemStack(icon);
            ItemMeta meta = item.getItemMeta();
            if (meta != null) {
                String displayName = HexColor.translate(section.getString("display-name", milestoneHours + "h"));
                String status = claimed ? "&a&l✔ OBTENU" : (unlocked ? "&e&l⏳ EN ATTENTE" : "&c&l🔒 VERROUILLE");
                meta.setDisplayName(HexColor.translate(status + " &8- ") + displayName);

                List<String> lore = new ArrayList<>();
                lore.add(HexColor.translate("&7Palier : &f" + milestoneHours + "h de jeu"));
                if (!claimed && !unlocked) {
                    double remaining = milestoneHours - hours;
                    lore.add(HexColor.translate(String.format("&7Temps restant estime : &f%.1fh", remaining)));
                }
                if (claimed) {
                    lore.add(HexColor.translate("&aRecompense deja recuperee."));
                } else if (unlocked) {
                    lore.add(HexColor.translate("&eRecompense en cours de distribution..."));
                }
                meta.setLore(lore);
                item.setItemMeta(meta);
            }

            inv.setItem(slot, item);
            slot++;
        }

        return inv;
    }
}
