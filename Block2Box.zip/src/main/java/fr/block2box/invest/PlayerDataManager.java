package fr.block2box.invest;

import fr.block2box.util.FileUtil;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Stocke, par joueur, dans /plugins/Block2Box/playerdata/<uuid>.yml :
 *  - playtime-seconds : compteur interne (utilise seulement si PlaceholderAPI absent)
 *  - claimed-milestones : liste des paliers /invest deja distribues (evite les doublons)
 * Toujours 100% YML, aucune base de donnees.
 */
public class PlayerDataManager {

    private final Plugin plugin;
    private final File folder;
    private final Map<UUID, YamlConfiguration> cache = new HashMap<>();
    private final Map<UUID, File> files = new HashMap<>();

    public PlayerDataManager(Plugin plugin) {
        this.plugin = plugin;
        this.folder = new File(plugin.getDataFolder(), "playerdata");
        FileUtil.ensureDir(folder);
    }

    private YamlConfiguration configFor(UUID uuid) {
        return cache.computeIfAbsent(uuid, id -> {
            File file = new File(folder, id + ".yml");
            files.put(id, file);
            return YamlConfiguration.loadConfiguration(file);
        });
    }

    public void save(UUID uuid) {
        YamlConfiguration cfg = cache.get(uuid);
        File file = files.get(uuid);
        if (cfg == null || file == null) return;
        try {
            cfg.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("[Block2Box] Impossible de sauvegarder playerdata/" + uuid + ".yml : " + e.getMessage());
        }
    }

    public long getInternalSeconds(UUID uuid) {
        return configFor(uuid).getLong("playtime-seconds", 0L);
    }

    public void addInternalSeconds(UUID uuid, long seconds) {
        YamlConfiguration cfg = configFor(uuid);
        cfg.set("playtime-seconds", cfg.getLong("playtime-seconds", 0L) + seconds);
        save(uuid);
    }

    public List<Integer> getClaimedMilestones(UUID uuid) {
        return new ArrayList<>(configFor(uuid).getIntegerList("claimed-milestones"));
    }

    public boolean hasClaimed(UUID uuid, int milestoneHours) {
        return getClaimedMilestones(uuid).contains(milestoneHours);
    }

    public void addClaimedMilestone(UUID uuid, int milestoneHours) {
        List<Integer> claimed = getClaimedMilestones(uuid);
        if (!claimed.contains(milestoneHours)) {
            claimed.add(milestoneHours);
            YamlConfiguration cfg = configFor(uuid);
            cfg.set("claimed-milestones", claimed);
            save(uuid);
        }
    }

    public void unload(Player player) {
        UUID uuid = player.getUniqueId();
        save(uuid);
        cache.remove(uuid);
        files.remove(uuid);
    }
}
