package fr.block2box;

import fr.block2box.commands.Block2BoxCommand;
import fr.block2box.commands.HalloweenCommand;
import fr.block2box.commands.InvestCommand;
import fr.block2box.commands.VoteCommand;
import fr.block2box.config.ConfigManager;
import fr.block2box.crates.CrateListener;
import fr.block2box.crates.CrateManager;
import fr.block2box.crates.KeyManager;
import fr.block2box.crates.PendingKeyListener;
import fr.block2box.halloween.HalloweenListener;
import fr.block2box.halloween.HalloweenQuestManager;
import fr.block2box.invest.PlayerDataManager;
import fr.block2box.invest.PlaytimeManager;
import fr.block2box.listeners.AfkListener;
import fr.block2box.listeners.GUIClickListener;
import fr.block2box.votifier.AntiSpamManager;
import fr.block2box.votifier.RSAKeyUtil;
import fr.block2box.votifier.VoteHandler;
import fr.block2box.votifier.VoteLogger;
import fr.block2box.votifier.VotifierServer;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

public class Block2Box extends JavaPlugin implements Listener {

    private ConfigManager configManager;
    private KeyManager keyManager;
    private CrateManager crateManager;

    private RSAKeyUtil rsaKeyUtil;
    private AntiSpamManager antiSpamManager;
    private VoteLogger voteLogger;
    private VoteHandler voteHandler;
    private VotifierServer votifierServer;

    private PlayerDataManager playerDataManager;
    private PlaytimeManager playtimeManager;

    private HalloweenQuestManager halloweenQuestManager;

    @Override
    public void onEnable() {
        getDataFolder().mkdirs();

        // ---- Configuration ----
        configManager = new ConfigManager(this);
        configManager.load();

        // ---- Caisses & cles ----
        keyManager = new KeyManager(this);
        crateManager = new CrateManager(this, configManager, keyManager);
        crateManager.loadAll();

        // ---- Quetes Halloween (necessite crateManager pour donner les cles) ----
        halloweenQuestManager = new HalloweenQuestManager(this, configManager, crateManager);
        halloweenQuestManager.load();

        // ---- Votifier ----
        rsaKeyUtil = new RSAKeyUtil(this);
        try {
            rsaKeyUtil.loadOrGenerate();
        } catch (Exception e) {
            getLogger().severe("[Block2Box] Erreur lors de la generation/chargement des cles RSA : " + e.getMessage());
        }
        antiSpamManager = new AntiSpamManager(this, configManager);
        antiSpamManager.load();
        voteLogger = new VoteLogger(this, configManager);
        voteHandler = new VoteHandler(this, configManager, antiSpamManager, voteLogger);
        voteHandler.load();

        // Si le vrai plugin NuVotifier (ou l'original Votifier) est installe, on l'utilise
        // A LA PLACE de notre serveur reseau maison : bien plus fiable (protocole deja
        // eprouve), et evite un conflit si les deux essaient d'ecouter le meme port.
        // NuVotifierBridge.register(...) detecte lui-meme la presence de l'API (par
        // reflexion) et s'enregistre si possible ; retourne false si absent/echec.
        boolean realVotifierBridged = fr.block2box.votifier.NuVotifierBridge.register(this, voteHandler);

        if (realVotifierBridged) {
            getLogger().info("[Block2Box] Plugin NuVotifier/Votifier detecte : utilisation de son VotifierEvent "
                    + "(le serveur reseau interne de Block2Box reste desactive). Configurez le port et les tokens "
                    + "directement dans plugins/NuVotifier/config.yml, pas dans celui de Block2Box.");
        } else {
            votifierServer = new VotifierServer(this, configManager, rsaKeyUtil, voteHandler);
            votifierServer.start();
            getLogger().info("[Block2Box] NuVotifier non detecte : utilisation du serveur votifier interne "
                    + "(config.yml -> votifier:). Pour plus de fiabilite, l'installation du vrai plugin "
                    + "NuVotifier est recommandee : Block2Box le detectera et l'utilisera automatiquement.");
        }

        // ---- /invest (playtime) ----
        playerDataManager = new PlayerDataManager(this);
        playtimeManager = new PlaytimeManager(this, configManager, playerDataManager);
        playtimeManager.start();

        // ---- PlaceholderAPI (optionnel) ----
        if (getServer().getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new fr.block2box.integration.Block2BoxExpansion(this, playtimeManager, crateManager).register();
            getLogger().info("[Block2Box] Placeholders enregistres aupres de PlaceholderAPI (prefixe %block2box_...%).");
        } else {
            getLogger().info("[Block2Box] PlaceholderAPI non detecte : les placeholders %block2box_...% ne seront pas disponibles.");
        }

        // ---- Commandes ----
        Block2BoxCommand mainCommand = new Block2BoxCommand(this, configManager, crateManager, rsaKeyUtil);
        getCommand("block2box").setExecutor(mainCommand);
        getCommand("block2box").setTabCompleter(mainCommand);
        getCommand("invest").setExecutor(new InvestCommand(configManager, playtimeManager));
        getCommand("vote").setExecutor(new VoteCommand(configManager));
        getCommand("halloween").setExecutor(new HalloweenCommand(configManager, halloweenQuestManager));

        // ---- Listeners ----
        getServer().getPluginManager().registerEvents(new CrateListener(crateManager, configManager), this);
        getServer().getPluginManager().registerEvents(new GUIClickListener(), this);
        getServer().getPluginManager().registerEvents(new AfkListener(playtimeManager), this);
        getServer().getPluginManager().registerEvents(new PendingKeyListener(crateManager, configManager), this);
        getServer().getPluginManager().registerEvents(new HalloweenListener(halloweenQuestManager), this);
        getServer().getPluginManager().registerEvents(this, this);

        getLogger().info("[Block2Box] Plugin active avec succes.");
    }

    @Override
    public void onDisable() {
        if (votifierServer != null) {
            votifierServer.stop();
        }
        getLogger().info("[Block2Box] Plugin desactive.");
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        if (playerDataManager != null) {
            playerDataManager.unload(event.getPlayer());
        }
    }
}
