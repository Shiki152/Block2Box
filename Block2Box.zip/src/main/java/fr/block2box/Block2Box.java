package fr.block2box;

import fr.block2box.commands.Block2BoxCommand;
import fr.block2box.commands.InvestCommand;
import fr.block2box.config.ConfigManager;
import fr.block2box.crates.CrateListener;
import fr.block2box.crates.CrateManager;
import fr.block2box.crates.KeyManager;
import fr.block2box.invest.PlayerDataManager;
import fr.block2box.invest.PlaytimeManager;
import fr.block2box.listeners.AfkListener;
import fr.block2box.listeners.GUIClickListener;
import fr.block2box.votifier.AntiSpamManager;
import fr.block2box.votifier.RSAKeyUtil;
import fr.block2box.votifier.VoteHandler;
import fr.block2box.votifier.VoteLogger;
import fr.block2box.votifier.VotifierServer;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

public class Block2Box extends JavaPlugin implements Listener {

    private ConfigManager configManager;
    private KeyManager keyManager;
    private CrateManager crateManager;

    private RSAKeyUtil rsaKeyUtil;
    private AntiSpamManager antiSpamManager;
    private VoteLogger voteLogger;
    private VoteHandler voteHandler;
    private VotifierServer votifierServer;

    private PlayerDataManager playerDataManager;
    private PlaytimeManager playtimeManager;

    @Override
    public void onEnable() {
        getDataFolder().mkdirs();

        // ---- Configuration ----
        configManager = new ConfigManager(this);
        configManager.load();

        // ---- Caisses & cles ----
        keyManager = new KeyManager(this);
        crateManager = new CrateManager(this, configManager, keyManager);
        crateManager.loadAll();

        // ---- Votifier interne ----
        rsaKeyUtil = new RSAKeyUtil(this);
        try {
            rsaKeyUtil.loadOrGenerate();
        } catch (Exception e) {
            getLogger().severe("[Block2Box] Erreur lors de la generation/chargement des cles RSA : " + e.getMessage());
        }
        antiSpamManager = new AntiSpamManager(this, configManager);
        antiSpamManager.load();
        voteLogger = new VoteLogger(this, configManager);
        voteHandler = new VoteHandler(this, configManager, antiSpamManager, voteLogger);
        votifierServer = new VotifierServer(this, configManager, rsaKeyUtil, voteHandler);
        votifierServer.start();

        // ---- /invest (playtime) ----
        playerDataManager = new PlayerDataManager(this);
        playtimeManager = new PlaytimeManager(this, configManager, playerDataManager);
        playtimeManager.start();

        // ---- Commandes ----
        Block2BoxCommand mainCommand = new Block2BoxCommand(this, configManager, crateManager, rsaKeyUtil);
        getCommand("block2box").setExecutor(mainCommand);
        getCommand("block2box").setTabCompleter(mainCommand);
        getCommand("invest").setExecutor(new InvestCommand(configManager, playtimeManager));

        // ---- Listeners ----
        getServer().getPluginManager().registerEvents(new CrateListener(crateManager, configManager), this);
        getServer().getPluginManager().registerEvents(new GUIClickListener(), this);
        getServer().getPluginManager().registerEvents(new AfkListener(playtimeManager), this);
        getServer().getPluginManager().registerEvents(this, this);

        getLogger().info("[Block2Box] Plugin active avec succes.");
    }

    @Override
    public void onDisable() {
        if (votifierServer != null) {
            votifierServer.stop();
        }
        getLogger().info("[Block2Box] Plugin desactive.");
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        if (playerDataManager != null) {
            playerDataManager.unload(event.getPlayer());
        }
    }
}
