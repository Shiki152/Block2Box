package fr.block2box.util;

import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

/**
 * Construit un ItemStack a partir d'une section YML "display-item" et
 * d'une liste d'enchantements au format "TYPE:NIVEAU".
 */
public final class ItemBuilder {

    private ItemBuilder() {
    }

    public static ItemStack fromSection(ConfigurationSection section, List<String> enchantLines, Logger logger) {
        if (section == null) {
            return new ItemStack(Material.STONE);
        }

        String materialName = section.getString("material", "STONE").toUpperCase();
        Material material = Material.matchMaterial(materialName);
        if (material == null) {
            if (logger != null) {
                logger.warning("[Block2Box] Materiau invalide dans la config : " + materialName + " -> STONE utilise a la place.");
            }
            material = Material.STONE;
        }

        int amount = Math.max(1, section.getInt("amount", 1));
        ItemStack item = new ItemStack(material, amount);
        ItemMeta meta = item.getItemMeta();

        if (meta != null) {
            String rawName = section.getString("name", null);
            if (rawName != null && !rawName.isEmpty()) {
                meta.setDisplayName(HexColor.translate(rawName));
            }

            List<String> rawLore = section.getStringList("lore");
            if (!rawLore.isEmpty()) {
                List<String> lore = new ArrayList<>();
                for (String line : rawLore) {
                    lore.add(HexColor.translate(line));
                }
                meta.setLore(lore);
            }

            boolean anyEnchant = false;
            if (enchantLines != null) {
                for (String line : enchantLines) {
                    if (line == null || line.isBlank()) continue;
                    String[] parts = line.split(":");
                    if (parts.length != 2) {
                        if (logger != null) logger.warning("[Block2Box] Ligne d'enchantement invalide : " + line);
                        continue;
                    }
                    Enchantment enchant = matchEnchant(parts[0].trim());
                    int level;
                    try {
                        level = Integer.parseInt(parts[1].trim());
                    } catch (NumberFormatException ex) {
                        if (logger != null) logger.warning("[Block2Box] Niveau d'enchantement invalide : " + line);
                        continue;
                    }
                    if (enchant != null) {
                        meta.addEnchant(enchant, level, true);
                        anyEnchant = true;
                    } else if (logger != null) {
                        logger.warning("[Block2Box] Enchantement inconnu : " + parts[0]);
                    }
                }
            }

            boolean wantGlow = section.getBoolean("glow", false);
            if (wantGlow && !anyEnchant) {
                // Astuce visuelle : enchant factice masque pour obtenir le "glint" sans texte d'enchantement.
                meta.addEnchant(Enchantment.LUCK, 1, true);
                meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
            } else if (anyEnchant) {
                // On garde les enchants visibles par defaut (pas de HIDE_ENCHANTS) pour la lisibilite des recompenses.
            }

            if (meta instanceof PotionMeta potionMeta) {
                List<String> potionLines = section.getStringList("potion-effects");
                List<Color> colors = new ArrayList<>();
                for (String line : potionLines) {
                    if (line == null || line.isBlank()) continue;
                    String[] parts = line.split(":");
                    if (parts.length != 3) {
                        if (logger != null) logger.warning("[Block2Box] Ligne d'effet de potion invalide (attendu EFFET:AMPLIFICATEUR:SECONDES) : " + line);
                        continue;
                    }
                    PotionEffectType type = matchPotionEffect(parts[0].trim());
                    if (type == null) {
                        if (logger != null) logger.warning("[Block2Box] Effet de potion inconnu : " + parts[0]);
                        continue;
                    }
                    int amplifier;
                    int seconds;
                    try {
                        amplifier = Integer.parseInt(parts[1].trim());
                        seconds = Integer.parseInt(parts[2].trim());
                    } catch (NumberFormatException ex) {
                        if (logger != null) logger.warning("[Block2Box] Amplificateur/duree invalide dans l'effet de potion : " + line);
                        continue;
                    }
                    potionMeta.addCustomEffect(new PotionEffect(type, seconds * 20, amplifier), true);
                    if (type.getColor() != null) colors.add(type.getColor());
                }
                if (!colors.isEmpty()) {
                    potionMeta.setColor(Color.mixColors(colors.toArray(new Color[0])));
                }
            }

            meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
            item.setItemMeta(meta);
        }

        return item;
    }

    private static Enchantment matchEnchant(String name) {
        String normalized = name.trim().toLowerCase().replace(' ', '_');
        try {
            org.bukkit.NamespacedKey key = org.bukkit.NamespacedKey.minecraft(normalized);
            Enchantment enchant = Enchantment.getByKey(key);
            if (enchant != null) return enchant;
        } catch (Exception ignored) {
            // ignore et tente les alias historiques ci-dessous
        }
        return switch (normalized) {
            case "sharpness" -> Enchantment.DAMAGE_ALL;
            case "efficiency" -> Enchantment.DIG_SPEED;
            case "unbreaking" -> Enchantment.DURABILITY;
            case "protection" -> Enchantment.PROTECTION_ENVIRONMENTAL;
            case "fortune" -> Enchantment.LOOT_BONUS_BLOCKS;
            case "looting" -> Enchantment.LOOT_BONUS_MOBS;
            case "fire_aspect" -> Enchantment.FIRE_ASPECT;
            case "mending" -> Enchantment.MENDING;
            case "luck" -> Enchantment.LUCK;
            default -> null;
        };
    }

    private static PotionEffectType matchPotionEffect(String name) {
        String normalized = name.trim().toLowerCase().replace(' ', '_');
        try {
            NamespacedKey key = NamespacedKey.minecraft(normalized);
            PotionEffectType type = Registry.EFFECT.get(key);
            if (type != null) return type;
        } catch (Exception ignored) {
            // ignore et tente les alias historiques ci-dessous
        }
        return switch (normalized) {
            case "haste" -> PotionEffectType.FAST_DIGGING;
            case "mining_fatigue" -> PotionEffectType.SLOW_DIGGING;
            case "strength" -> PotionEffectType.INCREASE_DAMAGE;
            case "instant_health" -> PotionEffectType.HEAL;
            case "instant_damage" -> PotionEffectType.HARM;
            case "jump_boost" -> PotionEffectType.JUMP;
            case "nausea" -> PotionEffectType.CONFUSION;
            case "resistance" -> PotionEffectType.DAMAGE_RESISTANCE;
            case "slow_falling" -> PotionEffectType.SLOW_FALLING;
            case "conduit_power" -> PotionEffectType.CONDUIT_POWER;
            case "dolphins_grace" -> PotionEffectType.DOLPHINS_GRACE;
            case "fire_resistance" -> PotionEffectType.FIRE_RESISTANCE;
            case "night_vision" -> PotionEffectType.NIGHT_VISION;
            case "water_breathing" -> PotionEffectType.WATER_BREATHING;
            case "speed" -> PotionEffectType.SPEED;
            case "slowness" -> PotionEffectType.SLOW;
            case "regeneration" -> PotionEffectType.REGENERATION;
            case "absorption" -> PotionEffectType.ABSORPTION;
            case "luck" -> PotionEffectType.LUCK;
            case "saturation" -> PotionEffectType.SATURATION;
            default -> null;
        };
    }
}
