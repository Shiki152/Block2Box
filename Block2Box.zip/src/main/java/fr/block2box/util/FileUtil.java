package fr.block2box.util;

import org.bukkit.plugin.Plugin;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

/**
 * Copie les fichiers embarques dans le jar (src/main/resources) vers le
 * dossier /plugins/Block2Box/ s'ils n'existent pas deja sur le disque.
 * N'ecrase jamais un fichier existant (pas de perte de configuration).
 */
public final class FileUtil {

    private FileUtil() {
    }

    public static void copyDefault(Plugin plugin, String resourcePath, File targetFile) {
        if (targetFile.exists()) {
            return;
        }

        File parent = targetFile.getParentFile();
        if (parent != null && !parent.exists()) {
            parent.mkdirs();
        }

        try (InputStream in = plugin.getResource(resourcePath)) {
            if (in == null) {
                plugin.getLogger().warning("[Block2Box] Ressource introuvable dans le jar : " + resourcePath);
                return;
            }
            Files.copy(in, targetFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            plugin.getLogger().severe("[Block2Box] Impossible de creer " + targetFile.getPath() + " : " + e.getMessage());
        }
    }

    public static void ensureDir(File dir) {
        if (!dir.exists()) {
            dir.mkdirs();
        }
    }
}
